import sys
reload(sys)
sys.setdefaultencoding('utf8')
sys.path.insert(0, "../../")

from chatterBot_WorkFlow.MonsterNer import MonsterAPIs

class LoadNerModels():
    """
    This class loads the  NER models and uses Monster api services
    """
    def __init__(self):
        try:
            print 'loading ner models ..'
            self.StartNERAPIs=MonsterAPIs.startAPIs()

        except Exception as e:
            raise ("APIs not started Exception (startAPIs )  due to :" + str(e))


if __name__=="__main__":
    LoadNerModels=LoadNerModels()

