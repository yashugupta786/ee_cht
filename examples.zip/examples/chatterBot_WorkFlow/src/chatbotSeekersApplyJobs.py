# -----------------------------all imports-----------------------------
__author__ = "Rakesh Sachdeva, Yashu Gupta"
import ast
import sys
import requests
import json
import os.path as path
reload(sys)
sys.setdefaultencoding('utf8')
sys.path.insert(0, "../../")
from abrivations import abbrivations
import re
import string
import UserMessages
import configparser
import random
from loggingmodule import getlogger
from chatterBot_WorkFlow.MonsterNer import MonsterNer
from chatterBot_WorkFlow.profanityfilter import ProfanityFilter
from chatterBot_WorkFlow.src.loc_id import get_locid

# --------------------------importing config-dir-one time----------------

CONFIG_DIR = path.abspath(path.join(__file__, "../../.."))
config_file_loc = CONFIG_DIR + "/chatterBot_WorkFlow/config/Config.cfg"
config_obj = configparser.ConfigParser()

# ----------------importing data from config--------------------------
try:
    config_obj.read(config_file_loc)
    HostIP = (config_obj.get("PortsAndModels", "apiHost"))
    apiPort = (config_obj.get("PortsAndModels", "apiPort"))
    debugLevel = int(config_obj.get("Logs", "debuglevel"))
    logfilenameconfig = config_obj.get("Logs", "logfilename")
    MaxTry = int(config_obj.get("BotConfig", "MaxTry"))
    BotConfiScore = float(config_obj.get("BotConfig", "BotConfiScore"))
    MaxCon = int(config_obj.get("BotConfig", "MaxCon"))
    BotConverCount = int(config_obj.get("BotConfig", "BotConverCount"))
    MaxFaqs = int(config_obj.get("BotConfig", "MaxFaqs"))
    url = (config_obj.get("globalurls", "url"))
    IndUrl = str(config_obj.get("globalurls", "IndUrl"))
    GulfUrl = str(config_obj.get("globalurls", "GulfUrl"))
    HkUrl = str(config_obj.get("globalurls", "HkUrl"))
    SgUrl = str(config_obj.get("globalurls", "SgUrl"))
    PhUrl = str(config_obj.get("globalurls", "PhUrl"))
    ThUrl = str(config_obj.get("globalurls", "ThUrl"))
    VnUrl = str(config_obj.get("globalurls", "VnUrl"))
    IdUrl = str(config_obj.get("globalurls", "IdUrl"))
    MyUrl = str(config_obj.get("globalurls", "MyUrl"))
except Exception as e:
    raise Exception("Config file error: " + str(e))

# ---------------------------------

LOG_DIR = path.abspath(path.join(__file__, "../../.."))
logfilename = LOG_DIR + "/logs/logs.log"
# ----------------------------------- Loggin Functionality--------------------------------------------------------------------------
loggerobj = getlogger.GetLogger(name="chatbot", logfileloc=logfilename, debuglevel=debugLevel)
logger = loggerobj.getlogger1()
USkills, URole, UExp, ULoc = {u'SKILL': []}, {u'ROLE': []}, {u'EXPERIENCE': []}, {u'LOCATION': []}
FaqCount = 0
AnswerType = ""


# ----------------------------------------------------Class start---------------------------------------------------
class Chatbot():
    """
    Chatbot class - main class which integrated different modules like NER,
    spell check, greetings classifier, faq classifier, dictionarys through micro web framework api

    """

    def __init__(self):
        """
        creating all the object for profanity ,NER ,user messages
        """
        try:
            self.monsterNerObj = MonsterNer.MonsterNER()
            self.ProfObj = ProfanityFilter()
            self.Allmsgs = UserMessages.IntializeMessages()

        except Exception as e:
            logger.error('Exception occured at Intializing (__init__) Objects : ' + str(e))
            raise Exception(str(e))
        # -----------------------------------------------------------------------------

    def intializeMessages(self):
        """

        :return: the function returns the welcome messages
        """
        getwelcomeMsgsList = []
        try:
            WelcomeMessages = self.Allmsgs.WelcomeMessages
            WelcomeMsg = random.choice(WelcomeMessages)
            getwelcomeMsgsList.append(WelcomeMsg)
            return getwelcomeMsgsList
        except Exception as e:
            logger.error('Exception occured at Intializing (intializeMessages) Welcome Messages : ' + str(e))
            print(Exception(str(e)))
            return getwelcomeMsgsList

    # -----------------------------------welcome message---------------------------------------------------------

    def assistOptions(self):
        """

        :return: all static messages
        """
        getAssistMsgList = []
        try:
            AskSkillRoleMessages = self.Allmsgs.AskSkillRoleMessages
            skillsRoleMsg = random.choice(AskSkillRoleMessages)
            getAssistMsgList.extend([skillsRoleMsg])
            return getAssistMsgList
        except Exception as e:
            logger.error('Exception occured at AssistING (assistOptions) Options  Messages : ' + str(e))
            print(Exception(str(e)))
            return getAssistMsgList

    # --------------------------------------------------------------------------------------------------------------
    def getUserInput(self):
        """
        :return:for user input from console
        """
        try:
            userQuest = raw_input("enter sentence")
        except:
            userQuest = ""
        return userQuest.lower()

    # -----------------------------------------------------------------------------------------------

    def getExperience(self, NerQuest, MonNerObj):
        """

        :param NerQuest: takes the query
        :param MonNerObj:
        :return: experience
        """
        count = 0
        try:
            expTag = MonNerObj.getExpTags(text=NerQuest)
            if expTag != {u'EXPERIENCE': []}:
                return expTag
            else:
                expTag = {u'EXPERIENCE': []}
            return expTag

        except Exception as e:
            logger.error('Exception occured at getting Experience (getExperience) tags  : ' + str(e))
            print(Exception(str(e)))
            expTag = {u'EXPERIENCE': []}
            return expTag

    # ---------------------------------------------------------------------------------------------------
    def convertAbbrivations(self, que):
        """
        :param que:
        :return: static dictionary
        """
        for word in abbrivations.keys():
            if word in que:
                que = re.sub(r'\b' + word + '\\b', abbrivations[word], que)
        return que

    # ----------------------------------------------------------------------------------------------
    def getFaqUrl(self):
        FaqUrl = 'http://inside.monster.com/privacy/faq.aspx'
        return '<a href=' + FaqUrl + ' target="_blank"> Click here </a>'

    # -----------------------------------------------------------------------------------------------

    def getNer(self, input):
        """

        :param input:
        :return: returns all the named entity recognition tags
        """
        NerQuest = input
        count = 0
        MonNerObj = self.monsterNerObj

        rolestags, skillstags, expTag, locTag = {'ROLE': []}, {'SKILL': []}, {u'EXPERIENCE': []}, {u'LOCATION': []}

        try:
            skillstags, rolestags, locTag = MonNerObj.getALLNERTags(text=NerQuest)

            expTag = self.getExperience(NerQuest, MonNerObj, )
            return rolestags, skillstags, expTag, locTag

        except Exception as e:
            logger.error('Exception occured at getting getNer (getNer) tags  : ' + str(e))
            print(Exception(str(e)))
            return rolestags, skillstags, expTag, locTag

    # ------------------------------------------------------------------------------------------------------------------------

    def getsearchUrl(self, URole, USkills, ULoc, UExp,domain_url):

        """

        :param URole: takes role
        :param USkills: takes skills
        :param ULoc: takes location
        :param UExp: takes experiences
        :return: returns a url appended with the skills,roles,location
        """

        searchUrl=domain_url
        data = searchUrl.split("/")
        searchUrl=data[0] + "//" + data[2]+"/"

        #p = '(?:http.*://)?(?P<host>[^:/ ]+).?(?P<port>[0-9]*).*'
        #searchUrl = 'https://www.monsterindia.com/'
        # searchUrl=searchUrl.replace("https:","")
        #m = re.search(p, searchUrl)
        #searchUrl=m.group('host')+'/'

        CompRoles = []
        USeachKeywords = []
        for role in URole['ROLE']:
            if role.endswith("##COMP"):
                role = role.replace("##COMP", "")
                CompRoles.append(role)
                CompFound = True
            else:
                CompRoles.append(role)

        USeachKeywords = list(set(CompRoles + USkills['SKILL']))

        try:
            if len(ULoc['LOCATION']) > 0 and len(UExp['EXPERIENCE']) > 0:
                searchUrl = searchUrl + (
                        " ".join(USeachKeywords) + " " + " ".join(UExp['EXPERIENCE']) + "-years-jobs-in-" + " ".join(
                    ULoc['LOCATION']) + ".html").replace(' ', '-')
            elif len(ULoc['LOCATION']) > 0:
                searchUrl = searchUrl + (
                        " ".join(USeachKeywords) + "-jobs-in-" + " ".join(ULoc['LOCATION']) + ".html").replace(' ', '-')
            elif len(UExp['EXPERIENCE']) > 0:
                searchUrl = searchUrl + (
                        " ".join(USeachKeywords) + " " + " ".join(UExp['EXPERIENCE']) + "-years-jobs.html").replace(' ',
                                                                                                                    '-')
            else:
                searchUrl = searchUrl + (" ".join(USeachKeywords) + "-jobs.html").replace(' ', '-')
            searchUrl = re.sub('-+', '-', searchUrl)
            return searchUrl, USeachKeywords
        except Exception as e:
            logger.error('Exception occured at getting search result (getsearchUrl) url  : ' + str(e))
            print(Exception(str(e)))
            return searchUrl, USeachKeywords

    # -------------------------------------Hitting Global api Monster--------------------------------------------------------------
    def fetch_data_cart(self, URole, USkills, ULoc, UExp, uLocation,domain_url):
        """
        :param URole: takes role
        :param USkills: takes skills
        :param ULoc: takes location
        :param UExp: takes exp
        :param uLocation: takes location
        :return: returns all jobs from the Monster API
        """
        jobDetails = {}
        jobCount = None
        CompFound = False
        CompRoles = []
        new_skills = ''
        url = IndUrl
        if  "monsterindia.com" in domain_url:
            url = IndUrl
        elif "monstergulf.com" in domain_url :
            url = GulfUrl
        elif  "monster.com.hk" in domain_url:
            url = HkUrl
        elif "monster.com.sg" in domain_url:
            url =SgUrl
        elif "monster.com.ph" in domain_url:
            url =PhUrl
        elif "monster.co.th" in domain_url:
            url =ThUrl
        elif "monster.com.vn" in domain_url:
            url =VnUrl
        elif "monster.co.id" in  domain_url:
            url = IdUrl
        elif "monster.com.my" in domain_url:
            url = MyUrl


        for role in URole['ROLE']:
            if role.endswith("##COMP"):
                role = role.replace("##COMP", "")
                CompRoles.append(role)
                CompFound = True
            else:
                CompRoles.append(role)
        joint_list = list(set(CompRoles + USkills['SKILL']))
        new_skills = ", ".join(joint_list)

        locid = []
        if len(ULoc['LOCATION']) == 0:
            ULoc['LOCATION'] = [uLocation]
        else:
            for i in ULoc['LOCATION']:
                for j, k in get_locid.iteritems():
                    if i == j:
                        locid.append(str(k))
        job_loc_id = ", ".join(locid)
        new_location = ", ".join(ULoc['LOCATION'])
        new_exp = ", ".join(UExp['EXPERIENCE'])
        tryReqs = 0
        try:
            while (tryReqs < 10):

                new_url_jobcart = url + new_skills + "&ind=&jbm=&ctp=&lmy=" \
                                  + new_location + "&mne=&mxe=&exp=" + new_exp \
                                  + "&cid=(null)&loc=" + job_loc_id + "&srt=rel&n=1&day=90"

                r = requests.get(new_url_jobcart)
                if r.status_code == 200:
                    break
                tryReqs = tryReqs + 1
            if r.status_code == 200:
                new_dict = r.text
                jobSearchResults = json.loads(new_dict)
                jobDetails = {}

                jobCount = (jobSearchResults["SEARCH_RESULT"]["COUNT"])

                for i, result in enumerate(jobSearchResults["SEARCH_RESULT"]["JOB_DETAIL"]):
                    if result['MINSAL'] is not None:
                        result_minsal = float(result["MINSAL"])
                    else:
                        result_minsal = 0.0
                    if result['MAXSAL'] is not None:
                        result_maxsal = float(result["MAXSAL"])
                    else:
                        result_maxsal = 0.0
                    maxSal = max(result_minsal, result_maxsal)
                    minSal = min(result_minsal, result_maxsal)
                    result['SAL'] = 'Not disclosed'
                    if minSal == None or (float(minSal) == float(0.0) and float(maxSal) == float(0.0)):
                        result['SAL'] = 'Not disclosed'
                    elif (float(minSal) >= float(0.0) and float(maxSal) > float(0.0)):
                        result['SAL'] = str(minSal) + "L-" + str(maxSal) + "L P.A "
                    loc = ""
                    if result.has_key("TRANSFORMED_LOC"):
                        loc = result['TRANSFORMED_LOC']

                    jobDetails[i] = {'COMPANY_NAME': result['COMPANY_NAME'], 'FOLDERID': result['FOLDERID'],
                                     'TITLE': result['TITLE'],
                                     'MINEXP-MAXEXP': result['MINEXP'] + '-' + result['MAXEXP'] + " years",
                                     'JD_LOGO': result['JD_LOGO'].replace("http:", "https:"), 'TRANSFORMED_LOC': loc,
                                     'SALARY': result['SAL'],
                                     'KEYSKILLS': result['KEYSKILLS']}
                return jobDetails, jobCount, CompFound
            else:
                logger.error("Monster Global gateway Api error")
                return jobDetails, jobCount, CompFound
        except Exception as e:
            logger.error('Exception occured at getting search result (getsearchUrl) url  : ' + str(e))
            print(Exception(str(e)))
            return jobDetails, jobCount, CompFound

    # ------------------------------------------------Extract info called from get data ----------------------------------------------------------------------------------------------------
    # ------------------------------------------------Get BotType and Answer------------------------------------------------------------------------------------------------
    def BotTypeAnswer(self, que, ServiceReqType):
        headers = {'Content-type': 'application/json'}
        data_json = {'data': que}
        ReqUrl = "http://" + HostIP + ":" + (apiPort) + "/" + ServiceReqType
        try:
            response = requests.post(ReqUrl, data=json.dumps(data_json), headers=headers)
            correctData = ast.literal_eval(response.text)
            botData = correctData["DATA"]
        except Exception as e:
            print "Bad request/connectivity Error with BotTypeAnswer API"
            raise e
        Score, Ans = float(botData[0]), str(botData[1])

        return Score, Ans

        # ------------------------------------------------spell checker called as service ----------------------------------------------------------------------------------------------------

    def spell_checkservice(self, que):
        headers = {'Content-type': 'application/json'}
        data_json = {'sentence': que}
        ReqUrl = "http://" + HostIP + ":" + (apiPort) + "/getCorrectSpelling"

        try:
            response = requests.post(ReqUrl, data=json.dumps(data_json), headers=headers)
            correctData = ast.literal_eval(response.text)

            spell_check_returned = str(correctData['DATA'][1])

        except Exception as e:
            print "Bad request/connectivity Error with BotTypeAnswer API"
            raise e

        return spell_check_returned

    # ---------------------------------------------Main method called to fetch one time data--------------------------------------------------
    def getBotTypeAnswer(self, que, ServiceReqType,domain_url):
        MonNerObj = self.monsterNerObj


        try:


            Score, Ans = MonNerObj.BotTypeAnswer(que, ServiceReqType=ServiceReqType)
            IsUrl = re.findall(r'https?://\w+\.(\w+\.\w+(\.\w+)?)/', Ans)
            listDomainToRemove = ["my.", "www."]
            domain_text  = domain_url.split("//")[-1].split("/")[0]
            for d in listDomainToRemove:
                if domain_text.startswith(d):
                    domain_text = domain_text[len(d):]
                    break
            if len(IsUrl) > 0:
                for url in IsUrl:
                    Ans = Ans.replace(url[0], domain_text)
                    Ans.replace("http:", "https:")


        except Exception as e:
            logger.error('Exception occured at getting getBotTypeAnswer  : ' + str(e))
            print Exception(str(e))
            return 0, ""
        return Score, Ans

    # ------------------------------------------------spell checker called as service ----------------------------------------------------------------------------------------------------
    def getSpell_checkservice(self, que):
        MonNerObj = self.monsterNerObj
        spell_check_returned = que
        try:
            spell_check_returned = MonNerObj.spell_checkservice(que=que)

        except Exception as e:
            logger.error('Exception occured at getting getSpell_checkservice  : ' + str(e))
            print(Exception(str(e)))
            return spell_check_returned

        return spell_check_returned

    # --------------------------------------------------------------------------------------------
    def LocBasedIntent(self, locTag, JobIntent, que):
        try:
            if locTag != {'LOCATION': []}:
                for intent in JobIntent:
                    if intent in que:
                        return True
            else:
                return False
        except Exception as e:
            logger.error('Exception occured at getting LocBasedIntent  : ' + str(e))
            print(Exception(str(e)))
            return False

    # -------------------------------------------------------------------------------------------
    def getQualification(self, que, qualification):
        qualiRoles = []
        for qual in qualification:
            if qual in que.split():
                qualiRoles.append(qual)

        return qualiRoles

    # --------------------------------------------------------------------------------------------
    def extractInfo(self, que, uLocation, uFname,domain_url):
        """
        Main method to get entity and integration of services
        :param que: takes  query
        :param uLocation: takes location
        :return: jobs, classifier ans
        """
        USkills, URole, UExp, ULoc = {u'SKILL': []}, {u'ROLE': []}, {u'EXPERIENCE': []}, {u'LOCATION': []}
        job_cart_url = {}
        responseList = []
        searchUrl = ""
        AnswerType = ''
        que = self.convertAbbrivations(que.lower())
        skillsFound = []
        global MaxFaqs, FaqCount
        # MonNerObj = self.monsterNerObj
        ProfObj = self.ProfObj
        FailureMsgs = self.Allmsgs.FailureMsgs
        NoJobsFound = self.Allmsgs.NoJobsFound
        ProfinityResponse = self.Allmsgs.ProfinityResponse
        successMessages = self.Allmsgs.successMessages
        NoCompJob = self.Allmsgs.NoCompJob
        JobIntent = self.Allmsgs.JobIntent
        qualification = self.Allmsgs.qualification
        PriorityFaqs = self.Allmsgs.PriorityFaqs
        # AskExpMessages = self.Allmsgs.AskExpMessages
        global BotConverCount
        hostUrl='www.monster.com.ph'
        if len(que.split()) > 50:
            FailMsg = random.choice(FailureMsgs)
            responseList.extend([str(FailMsg)])
            AnswerType = "News_Artical"
            return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

        try:
            if ProfObj.is_profane(que):
                profMsg = random.choice(ProfinityResponse)
                responseList.extend([str(profMsg)])
                AnswerType = "Profanity"
                return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

            urls = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', que)
            for eachUrl in urls:
                que = que.replace(eachUrl, "TokenForFoundUrl")

            for eachPhrase in PriorityFaqs:
                if eachPhrase in que:
                    BotConfidence, BotAns = self.getBotTypeAnswer(que, "FaqResult",domain_url)


                    if BotConfidence >= BotConfiScore:
                        responseList.extend([str(BotAns)])
                        AnswerType = "FaqsType"
                    else:
                        AnswerType = "FailureType"
                        FailMsg = random.choice(FailureMsgs)
                        responseList.extend([str(FailMsg)])
                    return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

            rolestags, skillstags, expTag, locTag = self.getNer(que)
            qualRoles = self.getQualification(que, qualification)
            if len(qualRoles) > 0:
                rolestags['ROLE'].extend(qualRoles)

            if skillstags != {'SKILL': []}:
                USkills = skillstags
            if rolestags != {'ROLE': []}:
                URole = rolestags
            if expTag != {u'EXPERIENCE': []}:
                UExp = expTag
            if locTag != {u'LOCATION': []}:
                ULoc = locTag

            if rolestags != {'ROLE': []} or skillstags != {'SKILL': []} or self.LocBasedIntent(locTag, JobIntent,
                                                                                               que) == True:
                # if rolestags != {'ROLE': []} or skillstags != {'SKILL': []} or locTag != {'LOCATION': []}:
                searchUrl, skillsFound = self.getsearchUrl(URole, USkills, ULoc, UExp,domain_url)
                job_cart_url, jobCount, CompFound = self.fetch_data_cart(URole, USkills, ULoc, UExp, uLocation,domain_url)
                if jobCount:
                    RsltLoadMsg = random.choice(successMessages)

                    if uFname != "" and uFname is not None:
                        responseList.extend(['<b>'+"Hey " + uFname+'</b>' + ", " + RsltLoadMsg])
                    else:
                        responseList.extend([RsltLoadMsg])

                elif CompFound == True:
                    NoJobforComp = random.choice(NoCompJob)
                    if uFname != "" and uFname is not None:
                        responseList.extend(['<b>'+"Hey " + uFname+'</b>' + ", " + NoJobforComp])
                    else:
                        responseList.extend([NoJobforComp])
                else:

                    NoJobsFoundMsg = random.choice(NoJobsFound)
                    if uFname != "" and uFname is not None:
                        responseList.extend(['<b>'+"Hey " + uFname +'</b>'+ ", " + NoJobsFoundMsg])
                    else:
                        responseList.extend([NoJobsFoundMsg])
                USkills, URole = {u'SKILL': []}, {u'ROLE': []}
                # logger.info(" Bot Answer:" + str(responseList))
                AnswerType = "JobsType"
                return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

            else:

                BotConverCount = BotConverCount + 1
                que = self.getSpell_checkservice(que)
                print("spell check returened:" + str(que))
                query = [que]
                strip_sent = []
                query = [''.join(c for c in s if c not in string.punctuation) for s in query]
                query = [s for s in query if s]
                for i in query:
                    strip_sent.append(re.sub('\s+', ' ', i).strip())
                query_lwr_Pred = [x.lower() for x in strip_sent]
                que = ''.join(query_lwr_Pred)
                ServiceReqType = "GetIntent"
                botScore, botType = self.getBotTypeAnswer(que, ServiceReqType,domain_url)

                if que.startswith("jobs in") or que.startswith("job in"):
                    NoJobsFoundMsg = random.choice(NoJobsFound)
                    if uFname != "" and uFname is not None:
                        responseList.extend(['<b>'+"Hey " + uFname +'</b>'+ ", " + NoJobsFoundMsg])
                    else:
                        responseList.extend([NoJobsFoundMsg])
                    AnswerType = "NoJobsFound"
                    return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

                if botType == 'faqs':
                    ServiceReqType = "FaqResult"
                    FaqCount = FaqCount + 1
                    AnswerType = "FaqsType"
                else:
                    ServiceReqType = "BotProfileResult"
                    AnswerType = "BotProfileType"

                BotConfidence, BotAns = self.getBotTypeAnswer(que, ServiceReqType,domain_url)
                if BotConfidence >= BotConfiScore:
                    responseList.extend([str(BotAns)])
                else:
                    AnswerType = "FailureType"
                    FailMsg = random.choice(FailureMsgs)
                    responseList.extend([str(FailMsg)])
                return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

        except Exception as e:
            logger.error('Exception occured at getting extractInfo (extractInfo) tags  : ' + str(e))
            print(Exception(str(e)))
            return (responseList, job_cart_url, searchUrl, AnswerType, skillsFound)

    def applyIntent(self,que):
        que=que.lower()
        #applyIntentType( 2 --->no action, 1--> apply, 0 --> next)
        applyIntentType=2
        ApplyJob=self.Allmsgs.ApplyJob
        NoApplyJob=self.Allmsgs.NoApplyJob
        NextJob=self.Allmsgs.NextJob
        try:
            for w in ApplyJob:
                if (w in que.split()):
                    applyIntentType=1
                    break
            if applyIntentType == 1:
                for n in NoApplyJob:
                    if n in que.split():
                        applyIntentType=2
                        break
            for nxt in NextJob:
                if nxt in que.split():
                    applyIntentType=0
                    break
        except Exception as e:
            logger.error('Exception occured at getting applyIntent (applyIntent) tags  : ' + str(e))
            print(Exception(str(e)))
            return str(applyIntentType)

        return str(applyIntentType)

    def first_voicequery(self,que,uFname):
        que=que.lower()
        voicemsg=self.Allmsgs.firstvoice
        voice_messg=random.choice(voicemsg)
        if uFname != "" and uFname is not None:
            voice_msg="Hey "+uFname+ " " + voice_messg
        else:
            voice_msg=voice_messg

        return str(voice_msg)


# -----------------------------------------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    query = "how to apply for  job AND category: apply"
    cb = Chatbot()
    getwelcomeMsgsList = cb.intializeMessages()
    print getwelcomeMsgsList
    getAssistMsgList = cb.assistOptions()
    print getAssistMsgList
    while True:
        que = cb.getUserInput()
        print cb.applyIntent(que=que)
        # responseList, job_cart_url, searchUrl, AnswerType, skillsFound = cb.extractInfo(que, "")
        # print responseList
        # # print job_cart_url
        # # print searchUrl
        # responseList = []
