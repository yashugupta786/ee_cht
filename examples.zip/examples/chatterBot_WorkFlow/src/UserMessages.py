import random


class IntializeMessages():
    def __init__(self):
        self.name_of_computer = ' Trumpy '
        self.name_of_user = ' '
        self.WelcomeMessages = [
            'Hi ' + self.name_of_user + ', Welcome to Monster! I can assist you in finding the perfect job. ',
            ]
        self.ProfinityResponse = ["Please don't get mad I'm trying my best.", "Please calm down I'm still learning.",
                                  "Currently, I can help with searching best jobs for you and also answering questions related to monster's portal,but I'm a keen learner!",
                                  "I am trying my level best to help you. Please bear with me.",
                                  "I can tell you are upset. If my answers were not helpful, Please bear with me."]

        self.AssistMessages = [

            'To find jobs in desired locations, mention complete profile with preferred cities. \n Eg: Data Scientist knowing Python with 5 yrs experience for Delhi, Bangalore',
            'I can help you to find the right job as per your profile.\n Just mention the Job Title/Skills, experience and preferred cities \n Eg: Software engineer knowing NLP with 5 yrs exp for Delhi, Mumbai',
            'Are you looking for a specific job opening?',
            "Please point me in the right direction sharing your profile, experience and preferred cities for job \nLike: Plant manager with 6 yrs experience for Delhi, Mumbai",
            "Do you have some specific Job Title / Skills  in mind? ",
            "Let me know the specifications of the job profile that you are looking for - \n Like: Android Developer with 6 yrs experience for Delhi, Mumbai"
        ]

        self.returnRstsMessages = [

            "I found these TOP matching jobs",
            "for you, pls go ahead and apply !",
            "Hurray ! Here are TOP jobs matching your requirements, go ahead and apply !",
            "I picked up these TOP jobs matching your specifications, go ahead and apply !"

        ]

        self.SkillRoleExample = ["Java", "Project Manager", "Customer Service Representative", "Receptionist",
                                 "Executive assistant",
                                 "Graphic Designer", "Manager", "Software engineer", "Business Analyst",
                                 "Account Executive",
                                 "Sales Representative", "Account Manager",
                                 "Financial Analyst", "Accountant", "Python", "Nursing", "marketing", "sales",
                                 "Teacher", "Software Programmer"]

        # skillsRandm = random.sample(SkillRoleExample, 2)

        self.AskSkillRoleMessages = [

            " I\'m just trying to put your requirements into words. Try something like Programming, Accountant  or any skill. For specific results mention your location and experience",
            "you can enter a position or a skill, for eg. iOS Developer, Project Manager . Do mention your experience and preferred location to see relevant jobs",
            "please let me know the job position like  Programming, Accountant  that you are looking for",
            "please mention your preferred location, experience and the job role like  Programming , Accountant",
            "kindly, let me know the job position that you are looking for like  Programming ,  accountant  . Please, mention your relevant experience and location too",
            " Can you please mention the specifications of the job profile that you are looking for. ",
            " Like: Android Developer with 6 yrs experience for Delhi, Mumbai",
            "Please, point me in the right direction by letting me know the complete  profile that you are looking for - Like: Data Scientist with 6 yrs experience for Delhi, Mumbai",
            "I can help you find the right job in desired locations. Just mention the Job Title/Skills, experience, preferred location. \n Eg: Receptionist with 3 yrs experience for Bangalore, Mumbai"

        ]

        self.NoJobsFound = [
            "Sorry ! Currently there are no active jobs that match your Profile, kindly mention different Job Title / skills to look for ",
            "Oopsies, I cannot find any job postings with the specifications that you have provided me.Try searching with different Job Title / skills together ",
            "Oh! I can\'t find relevant jobs with these specifications. Could you mention  some more skills pertaining to the job ? ",
            "Apologies, but I can\'t find what you are looking for. Please try some other Job Title / Skill/ Keyword  "

        ]

        self.successMessages = [

            "I found these TOP matching jobs for you, please go ahead and apply !",
            "Here are TOP jobs matching your requirements, go ahead and apply !",
            "I picked up these TOP jobs matching your specifications, go ahead and apply !"

        ]

        self.AskExpMessages = ['You can add your experience also. For example: 3 years of Experience in sales',
                               'Kindly mention your experience. for example 3-4 years of Experience in sales',
                               'Please, specify your experience. For example, 1-2 years of experience in Nursing',
                               'You could add relevant experience as well. For example: 2 years of experience in Marketing',
                               'Please, let me know the number of years that you have been working in the concerned field',
                               'Will you please, mention your experience? For example: 3 years of experience in sales',
                               'Please, do add your experience. Like, 1-2 years of experience in Teaching',
                               'How many years of experience do you have and in which field?',
                               'Please, add your experience. For example: 2 years of experience in Teaching',
                               'It would be good, if you mention your experience as well. Example, 1 year of experience as a programmer'
                               ]

        # LocExample = ["Mumbai", "Punjab", "Shillong", "Amritsar", "Kolkata", "Bihar", "Tamil Nadu", "Chandigarh", "Gurgaon",
        # "Chennai", "Noida", "Jharkhand", "Delhi", "Orissa", "West Bengal", "Rajasthan", "Bangalore", "Pune", "Lucknow","Maharashtra", "Hyderabad", "Karnataka", "NCR", "Gujrat"]
        # locRandm = random.sample(LocExample, 2)

        self.AskLocMessages = [
            "Please specify where you would like to do the search. For example: Bangalore, NCR ",
            "Where should I search? For example: Bangalore, NCR  or some other location",
            "Where should I look? For example: Bangalore, NCR  etc.",
            "Any preferred Location? \nFor example: Bangalore, NCR  etc.",
            "Do you have any preference regarding the job location? Like Bangalore, NCR or some other place",
            "Please, let me know your preferred location. LikeBangalore, NCR  etc.",
            "Do you want me to look for jobs at a specific location? For example: Bangalore, NCR ",
            "Will you please let me know your preferred location(s)? Like Bangalore, NCR  etc.",
            "Kindly, tell me your preferred location. For example: Bangalore, NCR ",
            "Do let me know the location you want me to perform the search in, for example Bangalore, NCR "
        ]

        self.options = {0: 'internship',
                        1: 'fresher',
                        2: 'experience', }

        self.yesList = ['yes', "true", "yeah", "1", "okay", "k", "ok"]
        self.qualification = ["fresher", "freshers", "graduate", "graduates", "12th", "10th", "diploma",
                              "degree holder",'abroad','international job']
        self.InternOption = ['0', 'intern', 'internship']
        self.FresherOption = ['1', 'fresher']
        self.ExperienceOption = ['2', 'exp', 'exper', 'experience']
        self.AssistOption = ['3', 'resume', 'apply', 'register']
        self.BotProfOption = ['4', 'you', 'u', 'ai']

        self.JobIntent = ["jobs", "job", "opening", "openings", "opportunity", "opportunities", "postion", "positions",
                          "post", "posts", "vacancy", "vacancies", "occupation", "vocation", "spot", "spots","location","area","city","in",'at']

        self.faqsListType = ['search job', 'relevant job', 'update resume', 'current opening', 'agencies', 'apply job',
                             'search application', 'applied', 'applicable jobs', 'register', 'put in',
                             'put in an application', 'update profile', 'change profile', 'update account',
                             'change account', 'job agent', 'job alert', 'agent', 'alert', 'filter', 'industry',
                             'functional', 'state', 'city', 'countries', 'country', 'site', 'locality', 'place',
                             'locale', 'area', 'venue', 'address', 'salary', 'ctc', 'package', 'delete', 'applied job',
                             'old resume', 'old password', 'change password', 'cover letter', 'password',
                             'password change', 'password upload', 'merge', 'user id', 'user', 'block', 'profile',
                             'update', 'activate', 'deactivate', 'delete', 'account', 'setting', 'manage account',
                             'update profile', 'mobile number', 'contact number', 'email address', 'date of birth',
                             'dob', 'registration', 'register', 'sign up', 'login', 'signin', 'new user',
                             'account,resume', 'cv', 'post', 'upload', 'update resume/cv', 'biodata', 'search job',
                             'openings', 'agencies', 'application', 'applications', 'status', 'position', 'money',
                             'fees', 'charge', 'apply', 'job', 'registration', 'sign up', 'change password',
                             'profile update', 'login', 'profile', 'password', 'information', 'update', 'alert',
                             'money', 'fees', 'charge', 'agents', 'alerts', 'pwd', 'cover letter', 'cover',
                             'length', 'log in', 'sign up', 'photo', 'pic', 'status', 'application', 'mobile phone',
                             'cell', 'chnge', 'pwd', 'alter', 'job application', 'status', 'experience', 'location',
                             'filter', 'login credentials', 'login', 'withdraw', 'application', 'job seeker',
                             ' email notifications', 'email', 'notifications', 'photograph', 'organization', 'industry',
                             'employment', 'sms', 'career', 'career wise', 'activate', 'qualified', 'directly',
                             'summary', 'detailed', 'credit card', 'cc', 'hired', 'hire', 'workspace', 'employers',
                             'username', 'appropriate', 'relevant', 'recommendation', 'recommend', 'searchable',
                             'confidential', 'necessary', 'mandatory', 'subscription', 'currrent', 'employer', 'salary',
                             'stand', 'letter', 'registration', 'membership', 'declined', 'browse', 'portal',
                             'network tab', 'recruiters',
                             "recruiter", 'premium', 'paid', 'monster education', 'Highlighter', 'booster', 'xpress',
                             'jobseeker','security code',
                             'user id', 'profile picture', 'multiple resume', 'search'
                             ]

        self.PriorityFaqs = ['update resume', 'update profile', 'change profile', 'update account',
                             'change account', 'job agent', 'job alert', 'old resume', 'old password',
                             'change password', 'cover letter', 'password change', 'password upload', 'settings',
                             'manage account', 'registration', 'sign up', 'profile update', 'email notifications',
                             'profile picture', 'multiple resume']

        self.NoCompJob = [
            "Currently there are no active jobs for this company. Do you want me to search something else ",
            "At the moment there are no such jobs. Would you like me to find other companies jobs",
            "Would like me to perform some other search, I can\'t seem to find job listings with this company"
            ]

        # self.faqsListType =[]

        self.FailureMsgs = [
            "Please let me know the Job Position that you are looking for. \nEg: Accountant job in Delhi with 3 yrs experience or ask questions related to monster",
            "Please mention your preferred Location, Experience and Job profile together.\n Eg: Jobs in Delhi for Digital Marketing with 5 yrs experience",
            "Can you please mention the Job profile that you want me to find, along with experience and city. \nLike: Sales with 12 yrs exp for Delhi",
            "Let me know your experience and preferred city along with the job position like Marketing Head, sales with 3 years experience.",
            "Please tell me your Job Profile like engineer,sales etc along with your experience and preferred job location together. like 'Sales with 12 yrs exp for Delhi'",
            "would you mind telling the company name like  'Jobs in Wipro' or skill together",

        ]

        self.ApplyJob=['yes','yeah','sure','yes please','please','go ahead','apply','okay','ok','like','love','yo','yoyo','han']
        self.NoApplyJob=['no','don\'t','do not','not','donot','dont','never','neah','naah','na','nahi']
        self.NextJob=['next','another','other']

        self.firstvoice=["how can i assist you?","how can i help you in finding jobs?","hello how can i help you?"]


if __name__ == "__main__":
    mesgsObj = IntializeMessages()
    c = mesgsObj.faqsListType
    c = list(set(c))
    print(c[1])

