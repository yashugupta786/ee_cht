stopper = ['is','a','to','by','an','at','be','eg','me','or','so','the','we','was','some','of',"my",'am','were','how','hi','you','on','what','will','i',
           'he','are','his','if','can','has','had','have','about','above','after','again','against','all','am','an','and','any','of','off','on','once','only','or','other','ought','our','ours',
            'so','some','such','than','that','the','their','what','which','who','whom','this','that','these','those','do'
           ,'your','youre','yours','well','want']
		   
queryStopper=['a','the']