dict_classifier = {

    "job seeker": "#661",
    "job seekers": "#661",

    "job agents": "#889",
    "job alert": "#889",
    "job agent": "#889",

    "sana": "#286",
    'monster': "#286",
    "portal": "#286",
    "monstercom": "#286",
    "monsterindiacom": "#286",
    "beast.com": "#286",
    "sara": "#286",
    "trumpy": "#286",
    "halen": "#286",
    "Mobo": "#286",
    "mojo": "#286",
    "kyra": "#286",


    "cv": "#288",
    "resume": "#288",
    "curriculum vitae": "#288",

    "mandatory": "#289",
    "compulsory": "#289",
    "required": "#289",

    "long": "#290",
    "length": "#290",
    "extensive": "#290",

    "basis": "#291",
    "criteria": "#291",
    "norm": "#291",
    "standard": "#291",
    "benchmark": "#291",
    "criterion": "#291",
    "scenario": "#291",

    "help": "#293",
    "assist": "#293",
    "guide": "#293",
    "aid": "#293",
    "help out": "#293",
    "guidance": "#293",
    "assistance": "#293",
    "avail": "#293",

    "make": "#292",
    "construct": "#292",
    "build": "#292",
    "create": "#292",
    "frame": "#292",
    "shape": "#292",
    "form": "#292",
    "mould": "#292",
    "devise": "#292",
    "constitute": "#292",
    "develop":"#292",
    "created": "#292",
    "made": "#292",

    "refresh": "#295",
    "reinvigorate": "#295",
    "revive": "#295",
    "enliven": "#295",
    "freshen": "#295",
    "rejuvenate": "#295",

    "correct": "#296",
    "revise": "#296",
    "change": "#296",
    "switch": "#296",
    "modify": "#296",
    "update": "#296",
    "amend": "#296",
    "shift": "#296",
    "alter": "#296",
    "vary": "#296",
    "interchange": "#296",

    "edit": "#296",
    "updating": "#296",

    "employer": "#994",
    "agency": "#994",
    "headhunter": "#994",
    "firm": "#994",

    "contact": "#297",
    "communication": "#297",
    "connection": "#297",

    "necessary": "#289",
    "need": "#289",
    "needful": "#289",

    "importance": "#299",
    "advantage": "#299",
    "benefits": "#299",
    "purpose": "#299",
    "benefit": "#299",
    "profit": "#299",
    "uses": "#299",
    "gain": "#299",


    "hire": "#300",
    "hiring": "#300",

    "job": "#3004",
    "jobs": "#3004",
    "employment": "#3004",
    "naukri": "#3004",

    "profession": "#900",
    "occupation": "#900",
    "career": "#900",
    "line of work": "#900",
    "field": "#900",

    "question": "#301",
    "query": "#301",
    "enquiry": "#301",
    "enquire": "#301",
    "inquiry": "#301",
    "concern": "#301",
    "que": "#301",
    "questions": "#301",

    "enhance": "#302",
    "improve": "#302",
    "better": "#302",
    "upgrade": "#302",

    "email": "#304",
    "e-mail": "#304",
    "e-message": "#304",
    "electronic mail": "#304",
    "mail": "#304",
    "emailid": "#304",

    "seeker account": "#777",
    "account": "#777",
    "acc": "#777",
    "ac": "#777",
    "profile": "#777",

    "stop": "#306",
    "cease": "#306",
    "finish": "#306",
    "end": "#306",
    "discontinue": "#306",
    "halt": "#306",
    "break off": "#306",

    "confirm": "#305",
    "verify": "#305",
    "authenticate": "#305",
    "approve": "#305",
    "validate": "#305",

    "apply": "#307",
    "register": "#307",
    "registering": "#307",
    "sign up": "#307",
    "signing up": "#307",
    "signup": "#307",
    "registration": "#307",
    "applying": "#307",

    "display": "#308",
    "show": "#308",
    "showing": "#308",

    # "delete": "#309",
    # "deleted": "#309",
    # "remove": "#309",
    # "removed": "#309",


    "information": "#310",
    "details": "#310",
    "info": "#310",

    "search engine": "#311",
    "browser": "#311",
    "google": "#311",

    "confidential": "#312",
    "hidden": "#312",

    "password": "#313",
    "pwd": "#313",
    "passwrd": "#313",
    "passwd": "#313",
    "pswrd": "#313",

    "user name": "#999",
    "user id": "#999",
    "credentials": "#999",
    "login credentials": "#999",

    "remember": "#314",
    "recall": "#314",

    "close": "#315",
    "rid": "#315",


    "login": "#318",
    "access": "#318",
    "log in": "#318",
    "sign in": "#318",
    "enter": "#318",

    "mobile phone": "#319",
    "cell phone": "#319",
    "cellphone": "#319",
    "phone": "#319",
    "mobile": "#319",

    "set up": "#997",
    "configure": "#997",

    "recommendation": "#321",
    "recommended": "#321",
    "recommend": "#321",
    "endorsement": "#321",

    "reference": "#322",
    "referral": "#322",

    "different": "#323",
    "differ": "#323",

    "complete": "#324",
    "completing": "#324",

    "guideline": "#325",
    "advice": "#325",
    "direction": "#325",

    "specified": "#326",
    "prescribed": "#326",

    "filling": "#327",
    "add": "#327",
    "fill": "#327",
    "adding": "#327",

    "appropriate": "#328",
    "relevant": "#328",
    "specific": "#328",
    "particular": "#328",

    "set": "#329",
    "record": "#329",
    "list": "#329",

    "post": "331",
    "publish": "#331",

    "receiving": "#332",
    "getting": "#332",
    "geting": "#332",
    "get": "#332",
    "receive": "#332",

    "tips": "#335",
    "tricks": "#335",
    "techniques": "#335",

    "key skills": "#336",
    "skill": "#336",
    "abilities": "#336",
    "skills": "#336",

    "print": "#337",
    "printable": "#337",

    "templates": "#338",
    "template": "#338",

    "evaluate": "#339",
    "assess": "#339",
    "examine": "#339",

    "filter": "#342",
    "filtering": "#342",

    "get back": "#345",
    "recover": "#345",
    "retrieve": "#345",

    "negotiate": "#346",
    "decide": "#346",
    "settle": "#346",

    "salary": "#347",
    "salry": "#347",
    "wage": "#347",

    "credit card": "#348",
    "cc": "#348",
    "bank card": "#348",
    "bank cards": "#348",
    "credit cards": "#348",
    "debit card": "#348",

    "photograph": "#349",
    "pic": "#349",
    "photo": "#349",
    "picture": "#349",
    "snapshot": "#349",

    "city": "#350",
    "location": "#350",

    "100": "#352",
    "hundred": "#352",

    "fees": "#400",
    "paid": "#400",
    "fee": "#400",
    "charges": "#400",
    "charge": "#400",

    "company": "#444",
    "organization": "#444",
    "compny": "#444",

    "process": "#992",
    "steps": "#992",
    "procedure": "#992",

    "and": "#991",
    "&": "#991",

    "entry level": "#990",
    "fresher": "#990",

    "prefer": "#796",
    "preferred": "#796",
    "preference": "#796",

    "sms": "#923",
    "sm": "#923",
    "short message service": "#923",

    "don't": "#887",
    "dont": "#887",
    "do not": "#887",

    "to": "#000",
    "two": "#000",

    "hi": "#001",
    "hii": "#001",
    "hiii": "#001",
    "hellow":"#001",

    "thank you": "#0002",
    "thanks": "#0002",
    "thank": "#0002",
    "thnx": "#0002",

    "good morning": "#0004",
    "gm": "#0004",

    "bye": "#0089",
    "cya": "#0089",
    "bye bye": "#0089",

    "color": "#0006",
    "colour": "#0006",

    "favourite": "#0007",
    "favorite": "#0007",
    "fav": "#0007",

    "movie": "#0015",
    "muvie": "#0015",
    "movies": "#0015",

    "are": "#0008",
    "r": "#0008",

    "mad": "#0009",
    "insane": "#0009",
    "crazy": "#0009",
    "mental": "#0009",

    "actor": "#0010",
    "actress": "#0010",

    "dead": "#0011",
    "death": "#0011",
    "die": "#0011",

    "chat bot": "#0017",
    "chatbot": "#0017",

    "notification": "#0025",
    "alert": "#0025",
    "warn": "#0025",

    "bot": "#0028",
    "definition_bot": "#0028",
    "definitionbot": "#0028",

    "cannot": "#0028",
    "can not": "#0028",
    "can't": "#0028",

    "planet": "#0029",
    "country": "#0029",

    "stupid": "#0033",
    "dumb": "#0033",
    "idiot": "#0033",
    "fool": "#0033",

    "talking":"#00005",
    "speak":"#00005",
    "speaking":"#00005",

    "ok":"#1115",
    "nice":"#1115",

    "number":"#1116",
    "num":"#1116",

}
