import logging
from logging.handlers import RotatingFileHandler
from logging.handlers import TimedRotatingFileHandler
import time

class GetLogger_feedback():
    def __init__(self, name=None, logfileloc=None, debuglevel=None):
        if name == None and logfileloc == None:
            raise Exception("Expected parameter: name, loffileloc and optional parameter debuglevel ")
        if debuglevel == None:
            debuglevel = 2
        self.name = name
        self.logfileloc = logfileloc
        self.debuglevel = debuglevel
        self.logger = None

    def getlogger2(self):

        if self.logger == None:
            self.logger = logging.getLogger(self.name)
            self.logger.setLevel(logging.DEBUG)
            self.formatter_ = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
            if self.debuglevel == 2:
                try:
                    formatter_ = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
                    handler = TimedRotatingFileHandler(self.logfileloc, when="D", interval=10)
                    handler.setLevel(logging.DEBUG)
                except Exception as e:
                    print "exception raised by logger"
                    print e
                    self.logger.error("Exception while creating handler in debug level 5" + str(e))

            # handler = RotatingFileHandler(self.logfileloc, mode='a', maxBytes=5 * 1024 * 1024, backupCount=2,
            #                               encoding=None, delay=0)
            # handler.setLevel(logging.ERROR)
            handler.setFormatter(self.formatter_)
            self.logger.addHandler(handler)
        loggerobj = self.logger
        return loggerobj
