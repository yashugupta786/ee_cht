# Run batch file  Monster_NER_Roles.bat and Monster_NER_skill.bat port used 8103 and 8101
import requests
import ast
import json
import os, sys
import codecs
from pymongo import MongoClient
import datetime, time
import configparser
import os.path as path

CONFIG_DIR = path.abspath(path.join(__file__, "../../"))
config_file_loc = CONFIG_DIR + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    HostIP = (config_obj.get("PortsAndModels", "apiHost"))
    apiPort = (config_obj.get("PortsAndModels", "apiPort"))
    NoRoleSkill = (config_obj.get("PortsAndModels", "NoRoleSkill"))
    RoleSuffix = (config_obj.get("PortsAndModels", "RoleSuffix"))
    MinNerScore = (config_obj.get("PortsAndModels", "MinNerScore"))
    MaxNerScore = (config_obj.get("PortsAndModels", "MaxNerScore"))
    allnerPort = (config_obj.get("PortsAndModels", "allnerPort"))
    MongoIP = (config_obj.get("mongoDetails", "MongoIP"))
    MongoPort = int(config_obj.get("mongoDetails", "MongoPort"))
except Exception as e:
    raise Exception("Config file error: " + str(e))

sys.path.insert(0, "../../")

nowtime = datetime.datetime.now()
timestamp = str(nowtime.year) + str(nowtime.month) + str(nowtime.day)
converId = int(timestamp) + 0


class MonsterNER(object):

    def __init__(self):
        global NoRoleSkill, RoleSuffix
        NoRoleSkill = os.path.join(os.path.dirname(os.path.realpath(__file__)), "models", NoRoleSkill)
        RoleSuffix = os.path.join(os.path.dirname(os.path.realpath(__file__)), "models", RoleSuffix)
        self.NoRoleSkill_list = []
        self.RoleSuffix_list = []
        self.Intent = ["jobs", "job", "opening", "openings", "opportunity", "opportunities", "postion", "positions",
                      "post", "posts", "vacancy", "vacancies", "occupation", "vocation", "spot", "spots"]
        self.industry = ["Power plant", "plant department", "plant store", "plant factory", "airport", "airline",
                         "bank", "banks", "it", "transport", "travels field", "Hospital sector", "railway ", "railways",
                         "government", "us/it staffing", "hotels", "hotel", "Logistical", "Building construction",
                         "civil", "store", "police", "construction", "pharma", "automobile", "Production Department",
                         "telecom", "hospital sector", "remittance process"]


        try:
            f = codecs.open(NoRoleSkill, encoding='utf-8')
            self.NoRoleSkills = f.readlines()
            for x in self.NoRoleSkills:
                x = x.lower().replace("\r\n", "").replace("\n", "")
                self.NoRoleSkill_list.append(x)

            f = codecs.open(RoleSuffix, encoding='utf-8')
            self.RoleSuffix = f.readlines()
            for x in self.RoleSuffix:
                x = x.lower().replace("\r\n", "").replace("\n", "")
                self.RoleSuffix_list.append(x.replace("\r\n", ""))

        except Exception as ex:
            print 'File not found'
            print ex
            self.NoRoleSkill_list = []

    # ------------------------------------------------------------------------------------------------------------------------
    def filterSkillsRoles(self, skills, roles):
        if len(skills['SKILL']) > 0:
            for i, x in enumerate(skills['SKILL']):
                for y in self.RoleSuffix:
                    y = y.replace("\r\n", "")
                    if y in x:
                        skills['SKILL'][skills['SKILL'].index(x)] = x.replace(y, "")
                        break
        for x in self.NoRoleSkill_list:
            if len(skills['SKILL']) > 0 and x in skills['SKILL']:
                skills['SKILL'].remove(x)
            if len(roles['ROLE']) > 0 and x in roles['ROLE']:
                roles['ROLE'].remove(x)
        skills['SKILL'] = list(set([c.strip() for c in skills['SKILL']]))
        roles['ROLE'] = list(set([c.strip() for c in roles['ROLE']]))
        return skills, roles

    # ------------------------------------------------------------------------------------------------------

    def getMonsLocs(self, text):
        data_json = {'data': text}
        locUrl = "http://" + HostIP + ":" + (apiPort) + "/getLocations"
        headers = {'Content-type': 'application/json'}
        try:
            response = requests.post(locUrl, data=json.dumps(data_json), headers=headers)
            locations = ast.literal_eval(response.text)
            locations["DATA"] = list(set(locations["DATA"]))
            loctags = {u'LOCATION': locations["DATA"]}
        except Exception as e:
            print "Bad request/connectivity Error with getMonsLocs API"
            loctags = {u'LOCATION': []}

        return loctags

    # --------------------------------------------------------------------------------------------------------------------

    def getExpTags(self, text):
        data_json = {'data': text}
        expUrl = "http://" + HostIP + ":" + (apiPort) + "/getExperience"
        headers = {'Content-type': 'application/json'}
        try:
            response = requests.post(expUrl, data=json.dumps(data_json), headers=headers)
            experience = ast.literal_eval(response.text)
            experience["DATA"] = list(set(experience["DATA"]))
            exptags = {u'EXPERIENCE': experience["DATA"]}
        except Exception as e:
            print "Bad request/connectivity Error with getExpTags API"
            exptags = {}

        return exptags

    # ---------------------------------------------------------------------------------------------------
    def getJobIntent(self, text, SKILLS, ROLES, LOCATIONS):
        try:
            intendFound = False
            # Intent = ["jobs", "job", "opening", "openings", "opportunity", "opportunities", "postion", "positions",
            #           "post", "posts", "vacancy", "vacancies", "occupation", "vocation", "spot", "spots"]
            if (len(SKILLS['SKILL']) > 0 or (len(ROLES['ROLE']) > 0)):
                if (len(LOCATIONS['LOCATION']) > 0):
                    intendFound = True
                    return text, SKILLS, ROLES, LOCATIONS
                for itword in self.Intent:
                    for eachword in text.split():
                        if eachword == itword:
                            intendFound = True
                            return text, SKILLS, ROLES, LOCATIONS
                lenRememingData = len(text.split()) - len(
                    (" ".join(SKILLS['SKILL']) + " ".join(ROLES['ROLE']) + " ".join(LOCATIONS['LOCATION'])).split())
                if (lenRememingData) <= 15:
                    intendFound = True
                    return text, SKILLS, ROLES, LOCATIONS
            # if intendFound == False:
            #     SKILLS = {'SKILL': []}
            #     ROLES = {'ROLE': []}
            #     LOCATIONS = {'LOCATION': []}
        except Exception as e:
            print "Bad request/connectivity Error with getJobIntent"
            return text, SKILLS, ROLES, LOCATIONS

        return text, SKILLS, ROLES, LOCATIONS

    # ------------------------------------------------------------------------------------------------------------------------------

    def checkProb(self, text, skills, roles, locs):
        global converId
        SKILLS = skills.keys()
        ROLES = roles.keys()
        LOCATIONS = locs.keys()
        minThreshold = float(MinNerScore)
        maxThreshold = float(MaxNerScore)
        converId = converId + 1
        try:
            taggedskills = dict(
                (k, v) for k, v in skills.items() if v >= maxThreshold and (v == 1.0) or len(k.split()) > 1)
            taggedroles = dict(
                (k, v) for k, v in roles.items() if v >= maxThreshold and (v == 1.0) or len(k.split()) > 1)

            SKILLS = taggedskills.keys()
            ROLES = taggedroles.keys()
            LOCATIONS = locs.keys()

            # ImpSkills = dict((k, v) for k, v in skills.items() if v >= minThreshold and v < maxThreshold)
            # ImpRoles = dict((k, v) for k, v in roles.items() if v >= minThreshold and v < maxThreshold)

            # if len(ImpRoles) > 0 or len(ImpSkills) > 0:
            # mongodata = {'converId ': converId, 'sentence ': text, 'ImpSkills': ImpSkills, 'ImpRoles': ImpRoles}
            # try:
            # connection.insert(mongodata)
            # print( "conversation id   stored :")
            # print converId
            # print "conversation id  :" + str(converId) + " stored"
            # except Exception as e:
            # print " MongoDB table insertion error :" + str(e)
            # return SKILLS, ROLES, LOCATIONS
        except Exception as e:
            print " getting errors in getting probs (checkProb) :" + str(e)
            return SKILLS, ROLES, LOCATIONS

        return SKILLS, ROLES, LOCATIONS

    # ---------------------------------------------------------------------------------------------------------------------------

    def getALLNERTags(self, text):
        ItFound = None
        for indusWord in self.industry:
            for intentword in self.Intent:
                if indusWord.lower() in text.split() and intentword.lower() in text.split() :
                    ItFound = indusWord
        SKILLS = {'SKILL': []}
        ROLES = {'ROLE': []}
        LOCATIONS = {'LOCATION': []}
        data_json = {'sentence': text, 'threshold': 0.30}
        expUrl = "http://" + HostIP + ":" + (allnerPort) + "/extractentity/fetchEntity"
        # GeoLoc = "http://" + HostIP + ":" + (apiPort) + "/getIpLoc"
        headers = {'Content-type': 'application/json'}
        try:
            response = requests.post(expUrl, data=json.dumps(data_json), headers=headers)
            responsedata = ast.literal_eval(response.text)
            skills = responsedata['skillList']
            roles = responsedata['roleList']
            locs = responsedata['locationList']
            taggedskills, taggedroles, taggedLocs = self.checkProb(text, skills, roles, locs)
            if ItFound:
                taggedroles.append(ItFound)
            MonsLocList = self.getMonsLocs(text=text)
            SKILLS = {'SKILL': (taggedskills)}
            ROLES = {'ROLE': (taggedroles)}
            if MonsLocList['LOCATION'] != []:
                LOCATIONS = MonsLocList
            else:
                LOCATIONS = {'LOCATION': (taggedLocs)}

            SKILLS, ROLES = self.filterSkillsRoles(SKILLS, ROLES)
            #text, SKILLS, ROLES, LOCATIONS = self.getJobIntent(text, SKILLS, ROLES, LOCATIONS)

        except Exception as e:
            print "Bad request/connectivity Error with getSkills API"
            return SKILLS, ROLES, LOCATIONS
        return SKILLS, ROLES, LOCATIONS

    # ---------------------------------------------------------------------------------------------------------------------------
    def BotTypeAnswer(self, que, ServiceReqType):
        headers = {'Content-type': 'application/json'}
        data_json = {'data': que}
        ReqUrl = "http://" + HostIP + ":" + (apiPort) + "/" + ServiceReqType
        try:
            response = requests.post(ReqUrl, data=json.dumps(data_json), headers=headers)
            correctData = ast.literal_eval(response.text)
            botData = correctData["DATA"]
        except Exception as e:
            print "Bad request/connectivity Error with BotTypeAnswer API"
            raise e
        Score, Ans = float(botData[0]), str(botData[1])

        return Score, Ans

    # ------------------------------------------------spell checker called as service ----------------------------------------------------------------------------------------------------
    def spell_checkservice(self, que):
        headers = {'Content-type': 'application/json'}
        data_json = {'sentence': que}
        ReqUrl = "http://" + HostIP + ":" + (apiPort) + "/getCorrectSpelling"

        try:
            response = requests.post(ReqUrl, data=json.dumps(data_json), headers=headers)
            correctData = ast.literal_eval(response.text)

            spell_check_returned = str(correctData['DATA'][1])
        except Exception as e:
            print "Bad request/connectivity Error with BotTypeAnswer API"
            raise e

        return spell_check_returned


if __name__ == "__main__":
    # text="i've been woring 3 years 3years in,how to, java, java developer, java , pyton ludhiana, bangalore, ludhiana, java "
    text = "i am marketing, autocad developer,sales, plumber developer from USA"
    text = "jobs in india and ludhiana in developer field and profile"
    text = "job agents,python, developers"
    text = "is"
    texts = ["stage http "]
    NerObj = MonsterNER()
    NerObj.getALLNERTags(text)
    correctStr = NerObj.spell_checkservice(que=text)
    print(correctStr)
    correctStr2 = NerObj.BotTypeAnswer(que=text, ServiceReqType="GetIntent")
    print(correctStr2)

    # exper = NerObj.getExpTags(text) for java developer administration and java script scinetist in noida
    # for text in texts:
    #     # expendsent=NerObj.getExpandedGramer(text=text)
    #     correctStr = NerObj.checkSpell(text=expendsent)
    # print expendsent
    # # print exper
    # print 'c ',correctStr

    # print NerObj.getALLNERTags(text=text)
    # NerObj.getExpTags(text=text)

    # print NerObj.getALLNERTags(text=correctStr)

    # print NerObj.getALLNERTags2(text=correctStr)
