from flask import Flask,jsonify
import json,requests
from flask_cors import CORS,cross_origin
from flask import json
from flask.globals import request
import spell_correct_text
import symp_spell
import nltk
app = Flask(__name__)
CORS(app)

#------------------------------------------------------------------------------------------------------------------------

@app.route('/getCorrectSpelling', methods=['POST'])
@cross_origin()
def getCorrectSpelling():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})

    try:
        data = dict(request.json)
        sentence = data["sentence"]
        tokens = nltk.word_tokenize(sentence.lower())
        token_return = spell_correct_text.correct_spell_by_words(tokens)

        # semi_correct_sentence = spell_correct_text.correct_spell(sentence)
        # #
        # tokens = semi_correct_sentence.split()
        correct_text = symp_spell.spell_corrector(token_return)

        if correct_text in ["", " ", '', None]:
            correct_text = sentence

        data_return = [sentence, correct_text]

        return json.dumps({"Status": "SUCCESS", "DATA": data_return, "Reason": ""})
    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": str(e)})



#----------------------------------------------------------------------------------------
def startAPIs():
    try:

        app.run(settings.APIHOST, port=(settings.APIPORT), debug=False, threaded=True)

    except Exception as e:
        print "APIs not started Exception (startAPIs ) at : "+str(settings.APIHOST)+":"+str(settings.APIPORT)+" due to :"+str(e)

if __name__=='__main__':
    startAPIs()


