import sys
sys.path.insert(0, "../../")
reload(sys)
sys.setdefaultencoding('utf8')
from flask import Flask, jsonify
import json, requests
from flask_cors import CORS, cross_origin
import ParseExperience
from flask import json
from flask.globals import request
import os
import platform
import pygeoip
import configparser
import nltk
import spell_correct_text
import symp_spell
from chatterBot_WorkFlow.MonsterNer import ParseLocation
from chatterBot_WorkFlow.MonsterNer import MonsterNer
from chatterBot_WorkFlow.BotProfile import BotProfile
from chatterBot_WorkFlow.BotProfile import intent_classifier
from chatterBot_WorkFlow.BotProfile import faq_bot
from chatterBot_WorkFlow.BotProfile import Mongo_connections

# ------------------------------------------------------------------------------------------
config_file_loc = "../config/Config.cfg"
config_obj = configparser.ConfigParser()
if not os.path.isfile(config_file_loc):
    config_file_loc = "../chatterBot_WorkFlow/config/Config.cfg"
config_obj = configparser.ConfigParser()
# --------------------------------------------------------------------------------------------
try:
    config_obj.read(config_file_loc)
    callJar_v3 = (config_obj.get("PortsAndModels", "callJar_v3"))
    outputFormat = (config_obj.get("PortsAndModels", "outputFormat"))
    nerJar = (config_obj.get("PortsAndModels", "nerJar"))
    apiHost = (config_obj.get("PortsAndModels", "apiHost"))
    apiPort = int(config_obj.get("PortsAndModels", "apiPort"))
    HostIP = (config_obj.get("PortsAndModels", "apiHost"))
    allnerPort = (config_obj.get("PortsAndModels", "allnerPort"))
    model_address = (config_obj.get("PortsAndModels", "ModelAddress"))
    java_path = str(config_obj.get("javapath", "javaPath"))

except Exception as e:
    raise Exception("Config file error: " + str(e))

# ---------------------objects intializing--------------------------------------
# GrammerObj = Word2VecGrammer.Word2VecContractionsCorrection()
mongo_obj=Mongo_connections.Mongo_data()
clasifier = BotProfile.BotProfileChatBot(mongo_obj)
faq_ques = faq_bot.FAQ_query(mongo_obj)
intent_classifier = intent_classifier.BotType(mongo_obj)

app = Flask(__name__)
CORS(app)


# # ------------------------------------------------------------------------------------------------------------------------------------
@app.route('/getExperience', methods=['POST'])
@cross_origin()
def getExperience():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})
    data = request.json
    if 'data' not in data:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": 'Expecting key as data'})
    try:
        statement = data['data']

    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Failed to parse: "data" should be str'})

    try:
        relatedterms = ParseExperience.parseExp(statement)
    except Exception as e:
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "Internal server error'})

    return json.dumps({"Status": "SUCCESS", "DATA": relatedterms, "Reason": ""})


# ------------------------------------------------------------------------------------------------------------------------

@app.route('/getLocations', methods=['POST'])
@cross_origin()
def getLocations():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})
    data = request.json
    if 'data' not in data:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": 'Expecting key as data'})
    try:
        statement = data['data']

    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Failed to parse: "data" should be str'})

    try:
        relatedterms = ParseLocation.get_city(statement)
    except Exception as e:
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "Internal server error'})

    return json.dumps({"Status": "SUCCESS", "DATA": relatedterms, "Reason": ""})


# -------------------------------------------running Ner java models---------------------------------------------------------------

def run_NERModels():
    print("Loading ner models2 ..")

    LoadModelCmd = model_address + java_path+" -mx25g -jar " + os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                                                     "models",
                                                                     nerJar) + " --server.port=" + (
                       allnerPort) + " --server.address=" + (HostIP) + " & "
    if ('linux') in (str(platform.platform()).lower()):
        LoadModelCmd = LoadModelCmd
    else:
        LoadModelCmd = 'start ' + LoadModelCmd

    try:
        os.system(LoadModelCmd)
        print(str(LoadModelCmd) + " model loaded successfully..")
    except Exception as e:
        print ("Exception in Loading (run_NERModels2) models" + str(e))


# --------------------------------------------------------------------------------------------------------------------------------------


@app.route("/getIpLoc", methods=["POST"])
@cross_origin()
def getIpLoc():
    r = requests.get(r'http://jsonip.com')
    ip = r.json()['ip']
    rawdata = pygeoip.GeoIP('C:/Users/rsachdev/Downloads/GeoLiteCity.dat')
    data = rawdata.record_by_name(ip)
    country = data['country_name']
    city = data['city']
    if city:
        return json.dumps({"Status": "SUCCESS", "LOCATION": city, "Reason": ""})
    if country:
        return json.dumps({"Status": "SUCCESS", "LOCATION": country, "Reason": ""})
    else:
        return json.dumps({"Status": "SUCCESS", "LOCATION": 'None', "Reason": ""})


# #-----------------------------------------------Classfier called----------------------------------

@app.route('/BotProfileResult', methods=['POST'])
@cross_origin()
def GetMlResult():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})
    data = request.json
    if 'data' not in data:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": 'Expecting key as data'})
    try:
        statement = data['data']
        statement = statement.encode('utf8')
    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Failed to parse: "data" should be str'})

    try:

        relatedterms = clasifier.getAnswer(statement)
        print("------------------------------------------------------------------------------")

        print 'response ml result ', relatedterms

        print("------------------------------------------------------------------------------")
    except Exception as e:
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "Internal server error'})

    return json.dumps({"Status": "SUCCESS", "DATA": relatedterms, "Reason": ""})


# -------------------------------Intent Classifier called # ---------------------------------------------------------
@app.route('/GetIntent', methods=['POST'])
@cross_origin()
def GetIntent():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})
    data = request.json
    if 'data' not in data:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": 'Expecting key as data'})
    try:
        statement = data['data']
        statement = statement.encode('utf8')
    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Failed to parse: "data" should be str'})

    try:

        top_score, bottype = intent_classifier.getAnswer_intent(statement)
        relatedterms = (max(top_score), bottype)
        print("------------------------------------------------------------------------------")

        print 'response ml intent score and type ', top_score, bottype

        print("------------------------------------------------------------------------------")
    except Exception as e:
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "Internal server error'})

    return json.dumps({"Status": "SUCCESS", "DATA": (relatedterms), "Reason": ""})


# # ----------------------------FAQ Classifier Called--------------------------------------------------------------------------

@app.route('/FaqResult', methods=['POST'])
@cross_origin()
def GetFAQ():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})
    data = request.json
    if 'data' not in data:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": 'Expecting key as data'})
    try:
        statement = data['data']
        statement = statement.encode('utf8')
    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Failed to parse: "data" should be str'})

    try:

        related_terms = faq_ques.getAnswer_faq(statement)
        print("------------------------------------------------------------------------------")

        print 'response ml FAQ score and type ', related_terms

        print("------------------------------------------------------------------------------")
    except Exception as e:
        return json.dumps({'Status": "ERROR", "DATA": None, "Reason": "Internal server error'})

    return json.dumps({"Status": "SUCCESS", "DATA": related_terms, "Reason": ""})


# ---------------------------------------------SPELL CHECK called----------------------
@app.route('/getCorrectSpelling', methods=['POST'])
@cross_origin()
def getCorrectSpelling():
    if request.method != 'POST':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only accept POST request"})
    if not request.headers['Content-Type'] == 'application/json':
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": "Only  accept Content-Type:application/json"})
    if not request.is_json:
        return json.dumps({"Status": "ERROR", "DATA": None,
                           "Reason": 'Expecting json data in the form {"data":"VALUE"}'})

    try:
        data = dict(request.json)
        sentence = data["sentence"]
        tokens = nltk.word_tokenize(sentence.lower())
        token_return = spell_correct_text.correct_spell_by_words(tokens)
        correct_text = symp_spell.spell_corrector(token_return)

        if correct_text in ["", " ", '', None]:
            correct_text = sentence

        data_return = [sentence, correct_text]

        return json.dumps({"Status": "SUCCESS", "DATA": data_return, "Reason": ""})
    except Exception as e:
        return json.dumps({"Status": "ERROR", "DATA": None, "Reason": str(e)})


# ---------------------------------------------------------------------------

def startAPIs():
    try:
        run_NERModels()
        app.run("0.0.0.0", port=(apiPort), debug=False, threaded=True)
        app.run()


    except Exception as e:
        raise ("APIs not started Exception (startAPIs ) at : " + str(apiHost) + ":" + str(apiPort) + " due to :" + str(
            e))


if __name__ == '__main__':
    startAPIs()
