import codecs,re,os,sys

import configparser
config_file_loc = "../config/Config.cfg"
config_obj = configparser.ConfigParser()
if not os.path.isfile(config_file_loc):
    config_file_loc = "../chatterBot_WorkFlow/config/Config.cfg"


try:
    config_obj.read(config_file_loc)
    #RolePort = (config_obj.get("PortsAndModels", "RolePort"))
    locationslist = (config_obj.get("PortsAndModels", "locations"))

except Exception as e:
    raise Exception("Config file error: " + str(e))
sys.path.insert(0, "../../")

locationslist=os.path.join(os.path.dirname(os.path.realpath(__file__)),"models",locationslist)
f = codecs.open(locationslist, encoding='utf-8')
loc_list=f.readlines()
whitespace=''
locations=[]
replace_dict = {}
for x in loc_list:
    locations.append(str(x.lower().replace("\r\n","").replace("\n","")))
locations.sort(key=lambda x: len(x.split()), reverse=True)
for x in locations:
    #if ', ' not in x:
    replace_dict[x.lower()]='Location&Start'+x.lower()+'Location&End'
pattern = re.compile("|".join(r'\b%s\b'% re.escape(k)  for k in replace_dict  ))


def get_city(statement):
    LocS=[]
    try:
       text = pattern.sub(lambda m: replace_dict[m.group(0)], statement.lower())
       patterns = re.findall(r'Location&Start[a-z0-9 ]+Location&End', text)
       for x in patterns:
           LocS.append(x.replace("Location&Start","").replace("Location&End",""))
    except Exception as e:
        print(e)
        return LocS

    return LocS




if __name__=="__main__":
    print get_city('i live in america  , bangalore, new delhi , delhi,america,singapore, malaysia ,cai')





