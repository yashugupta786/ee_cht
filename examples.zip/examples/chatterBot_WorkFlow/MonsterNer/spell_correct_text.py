#------------author Ankit Jain----------------------------------------------
import re
import time
file_cursor = open("spelling_mistakes.txt", "r")
correct_incorrect_words = file_cursor.readlines()
correct_words = []
incorrect_words = []

for line in correct_incorrect_words:
    words = line.split("|")
    incorrect_words.append(words[0].lower().strip("\n"))
    correct_words.append(words[1].lower().strip("\n"))

def correct_spell(text):
    text = text.lower()
    correct_text = text

    for index, incorrect_word in enumerate(incorrect_words):
        correct_text = re.sub(r'\b%s\b' % incorrect_word, correct_words[index], correct_text)

    return correct_text

def correct_spell_by_words(tokens):
    token_output = tokens
    for i, word in enumerate(tokens):
        if incorrect_words.__contains__(word):
            index = incorrect_words.index(word)
            token_output[i] = correct_words[index]
    return token_output


# stmt = "jaba develper jobs in deli".split()
# # while stmt != "exit":
# #     stmt = raw_input("enter text !!")
#
# first = time.time()
# print correct_spell("jaba develper jobs in deli")
# second = time.time()
# print second-first
#
# third = time.time()
#
# print correct_spell_by_words(stmt)
# fourth = time.time()
# print fourth-third
