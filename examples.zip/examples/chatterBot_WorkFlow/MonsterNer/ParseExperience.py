import re
regex=  "\\s*\\d*?.?\\d+\\s?y[e]*[a]*rs?"
#regex=  "\\s*\\d*?.?\\d+\\s?y[e]*[a]*[s]*rs?"
def parseExp(statement):
    try:
        statement=re.sub(' +',' ',statement)
        matches = re.finditer(regex, statement)

        matchesall = []
        for matchNum, match in enumerate(matches):
           matchesall.append(str(match.group()))
        experinceList=[]
        exp = matchesall
        for eachitem in exp:
            experinceList.append(re.findall('\d+', eachitem)[0])

    except Exception as e :
        print (" exception Occured :"+str(e))
        experinceList=[]


    return experinceList



if __name__ == "__main__":
    quries=['I bought a car  it was 1 year -2months expensive',
        'i am having experience of 2 yearsand31 months',
        'i am having experience of 3 years - 3 months' ,
        'i am having experience of 0 years-3 months',
         'i am having experience of 52.11 years',
        'i am having experience of 6-14year',
        'i am having experience of 7years-3months',
        'i am having experience of 8 years-3months',
        'i am having experience of 9.11 years',
        'i am having experience of 10-141     year',
        'i am having experience of 11 year',
        'i am a fresher',
        'i am  having no experience ',
        ' 4years',
        '5years of experience in machine learning',
         'looking for java developers in java5 years'

    ]
    for statement in quries:
        exp=parseExp(statement)
        print exp
