import os.path as path
import configparser
import urllib
import pymongo
bot_profile_config = path.abspath(path.join(__file__, "../.."))
config_file_loc = bot_profile_config + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    MongoIP = (config_obj.get("mongoDetails", "MongoIP"))
    MongoPort = int(config_obj.get("mongoDetails", "MongoPort"))
    db_name = (config_obj.get("mongoDetails", "db_name"))
    mongo_username = (config_obj.get("mongoDetails", "mongo_username"))
    mongo_pwd = (config_obj.get("mongoDetails", "mongo_pwd"))
except Exception as e :
    print(Exception(str(e)))

class MongoSession():
    def __init__(self):
        mongo_uri = "mongodb://" + mongo_username + ":" + urllib.quote(mongo_pwd) + "@" + MongoIP + "/" + db_name
        client = pymongo.MongoClient(mongo_uri)
        self.data = eval("client." + db_name)
        # client.close()

    def Context_collections(self,sessionid,query_send):
        try:
            self.userSession = self.data.Session_chatbot
            # all_context = self.userSession.find({'Sessions': sessionid})
            # for i in all_context:
            #     print(i)
            data_query = self.userSession.find_one({'Sessions': sessionid})
            if data_query is None:
                self.userSession.save({'Sessions': sessionid ,"query":query_send})
                return "No Session found and its saved in the DB"
            else:
                return data_query
        except Exception as e:
            print(Exception)
sessionid="7B 22p 22 3A1 2C 22s 22 3A15329f1c4sgsgsg91ff7efhxfh294914e0bccc"
query_send="python jobs"
obj1=MongoSession()
result=obj1.Context_collections(sessionid,query_send)
print(result)