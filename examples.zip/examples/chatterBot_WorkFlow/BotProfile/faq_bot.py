__author__ = "Yashu Gupta,Rakesh Sachdeva"
# ---------------------------------------ALL IMPORTS------------------------------------------------------------------------------------------->>
import nltk, string
import os.path as path
bot_profile_config = path.abspath(path.join(__file__, "../.."))
config_file_loc = bot_profile_config + "/config/Config.cfg"
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from chatterBot_WorkFlow.src.dictionary_bot import dict_classifier
from chatterBot_WorkFlow.src.stop_words import stopper
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn import preprocessing
lemma = nltk.WordNetLemmatizer()
import re, sys
import configparser
from Mongo_connections import Mongo_data
reload(sys)
sys.setdefaultencoding('utf8')
sys.path.insert(0, "../../")
# from chatterBot_WorkFlow.src.chatbotSeekersApplyJobs import logger
# ----------------------Defining thresholds------------------------------------------
upperThresh = 0.58
lowerThresh = 0.28

# -------------------------------------Conigs import---------------------------------------------
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    debugLevel = int(config_obj.get("Logs", "debuglevel"))
    logfilenameconfig = config_obj.get("Logs", "logfilename")
    MaxTry = int(config_obj.get("BotConfig", "MaxTry"))
    BotConfiScore = float(config_obj.get("BotConfig", "BotConfiScore"))
    MaxCon = int(config_obj.get("BotConfig", "MaxCon"))
    BotConverCount = int(config_obj.get("BotConfig", "BotConverCount"))
    MaxFaqs = int(config_obj.get("BotConfig", "MaxFaqs"))
except Exception as e:
    raise Exception("Config file error: " + str(e))

# <<------------------- fetching the one time data from the database for the model training---------------------------------------------------->>
TEXT_CLASSIFIER = None


class FAQ_query(object,Mongo_data):
    """
      FAQ_query class - model training for intent classfication
      classifier used SGD with svm quatratic (modified huber loss),TFidf vectorizer 
      :return class returns the answer with the score
    """

    def __init__(self,mongo_obj):
        self.mongo_list = mongo_obj.all_collections()
        self.feature_questions_faq = self.mongo_list[3]
        self.feature_lables_faq= self.mongo_list[4]
        self.all_ans_faq = self.mongo_list[5]



    def ml_chatbot(self):
        """
               Training the machine learning model for one time classfication for greetings
               parameters required SGD engine , with SVM
               libray used for training the model SK-LEarn

               :return: Text classifier(vector)
        """
        try:
            global TEXT_CLASSIFIER
            feature_questions =self.feature_questions_faq
            feature_lables = self.feature_lables_faq
            _feature_questions = []
            feature_questions_output = []
            _feature_questions_noun = []
            _feature_questions_verb = []
            feature_questions_punct = [''.join(c for c in s if c not in string.punctuation) for s in feature_questions]
            feature_questions_spc = [s for s in feature_questions_punct if s]
            for i in feature_questions_spc:
                _feature_questions.append(re.sub('\s+', ' ', i).strip())
            feature_questions_lwr = [x.lower() for x in _feature_questions]
            feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                                      feature_questions_lwr]
            for i in feature_questions_noun:
                _feature_questions_noun.append(" ".join(i))
            feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                                      _feature_questions_noun]
            for i in feature_questions_verb:
                _feature_questions_verb.append(" ".join(i))
            for s in _feature_questions_verb:
                for word in dict_classifier.keys():
                    if word in s:
                        s = re.sub(r'\b' + word + '\\b', dict_classifier[word], s)
                feature_questions_output.append(s)
            self.label_encoder_data = preprocessing.LabelEncoder()
            self.label_encoder_data.fit(feature_lables)
            interpretation_all_data = self.label_encoder_data.transform(feature_lables)
            stoppy_words = [(x.strip()) for x in stopper]
            count_vectorizer = CountVectorizer(ngram_range=(1, 2), stop_words=stoppy_words)
            text_classifier = Pipeline([
                ('vectorizer', count_vectorizer),
                ('clf', SGDClassifier(loss='modified_huber',
                                      alpha=1e-3,
                                      n_jobs=-1,
                                      max_iter=25,
                                      random_state=0,
                                      shuffle=True))
            ])
            TEXT_CLASSIFIER = text_classifier.fit(feature_questions_output, interpretation_all_data)

            global flag
            flag = True
        except Exception as exception:
            print (str(exception))

    def fetch_interpreted(self, question, dict_classifier):
        """
        :param question:
        :param dict_classifier:
        :return: questions, probablity score, vector
        """
        global TEXT_CLASSIFIER
        if TEXT_CLASSIFIER is None:
            self.ml_chatbot()
            print("faq _____fit again___")
        query = [question]
        query_label = []
        _feature_questions_noun_user = []
        _feature_questions_verb_user = []

        feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                                  query]
        for i in feature_questions_noun:
            _feature_questions_noun_user.append(" ".join(i))
        feature_questions_verb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                                  _feature_questions_noun_user]
        for i in feature_questions_verb:
            _feature_questions_verb_user.append(" ".join(i))
        for s in _feature_questions_verb_user:
            for word in dict_classifier.keys():
                if word in s:
                    s = re.sub(r'\b' + word + '\\b', dict_classifier[word], s)
            query_label.append(s)
        otherq = []
        scores = []
        pred = TEXT_CLASSIFIER.predict(query_label)
        otherpreds = TEXT_CLASSIFIER.predict_proba(query_label)[0]
        i = 0
        limit = 3
        if (len(otherpreds) < 3):
            limit = len(otherpreds)
        while i < limit:
            max_score = np.argmax(otherpreds)
            otherq.append(max_score)
            scores.append(otherpreds[max_score])
            otherpreds[max_score] = -1
            i += 1
        inter_q = self.label_encoder_data.inverse_transform(pred)
        return inter_q, scores

    def return_answer(self, returned_label,faq_ans):
        """
        :param returned_label: 
        :return:answer 
        """
        try:
            returned_answers = []
            returned_question = []
            for x in faq_ans:
                if x["qid"] == int(returned_label):
                    url=re.findall('((http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?)',x['Answer'])
                    if len(url) >0 and url[0][0]:
                        actualurl=url[0][0]
                        uAnswer= x['Answer'].replace(actualurl, "<b><a href=\"" + actualurl + "\" target=\"_blank\" > click here</a> </b>")
                        returned_answers.append(uAnswer)
                        break
                    else:
                        returned_answers.append(x['Answer'])
            return returned_answers[0]
        except Exception as exception:
            print (str(exception))
            return '', ''

    def getAnswer_faq(self, que):
        """
                :param que:
                :return: top score ,Bottype
        """
        question = que
        inter_q, scores_received = (self.fetch_interpreted(question, dict_classifier))
        returned_label = str(inter_q[0])
        top_score = scores_received[0]
        return top_score, self.return_answer(returned_label,self.all_ans_faq)


#
if __name__ == "__main__":
    question = ""
    mongo_obj =Mongo_data()
    gtObj = FAQ_query(mongo_obj)
    while question != "exit()":
        que = raw_input("Enter Sentence: ")
        score, ans = gtObj.getAnswer_faq(que)
        print (score, ans)
