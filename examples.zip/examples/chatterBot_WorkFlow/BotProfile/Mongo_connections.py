import os.path as path
import configparser
import urllib
import pymongo
bot_profile_config = path.abspath(path.join(__file__, "../.."))
config_file_loc = bot_profile_config + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    MongoIP = (config_obj.get("mongoDetails", "MongoIP"))
    MongoPort = int(config_obj.get("mongoDetails", "MongoPort"))
    db_name = (config_obj.get("mongoDetails", "db_name"))
    mongo_username = (config_obj.get("mongoDetails", "mongo_username"))
    mongo_pwd = (config_obj.get("mongoDetails", "mongo_pwd"))
except Exception as e :
    print(Exception(str(e)))



class Mongo_data():
    def __init__(self):

        mongo_uri = "mongodb://" + mongo_username + ":" + urllib.quote(mongo_pwd) + "@" + MongoIP + "/" + db_name
        client = pymongo.MongoClient(mongo_uri)
        self.data = eval("client." + db_name)
        client.close()


    def all_collections(self):
        try:
            feature_questions_greetings=[]
            feature_lables_greetings=[]
            all_ans_greetings = []
            faq_bot_questions=[]
            faq_bot_lables=[]
            faq_answers_data=[]
            intent_classifier_questions=[]
            intent_classifier_labels=[]

#live
            # self.combine_classifier = self.data.intentClassifier
            # self.Greetings_answers_data = self.data.Greetings_answers_data
            # self.Greetings_training_data = self.data.Greetings_training_data
            # self.FAQ_answers_data = self.data.Faqs_answers_data
            # self.FAQ_training_data = self.data.Faqs_training_data
            # Greetings_training = self.Greetings_training_data.find({})
            # intent_classifier=self.combine_classifier.find({})
            # Greetings_answers = self.Greetings_answers_data.find({})
            # Faq_training = self.FAQ_training_data.find({})
            # faq_answers = self.FAQ_answers_data.find({})

#test
            self.combine_classifier = self.data.ch_intent
            self.Greetings_answers_data = self.data.ch_greeting_ans
            self.Greetings_training_data = self.data.ch_greeting_training
            self.FAQ_answers_data = self.data.ch_faq_seed
            self.FAQ_training_data = self.data.ch_faq_training
            Greetings_training = self.Greetings_training_data.find({})
            intent_classifier=self.combine_classifier.find({})
            Greetings_answers = self.Greetings_answers_data.find({})
            Faq_training = self.FAQ_training_data.find({})
            faq_answers = self.FAQ_answers_data.find({})


            for _ in intent_classifier:
                intent_classifier_questions.append(_['questions'].strip())
                intent_classifier_labels.append(int(_['qid']))

            for x in Greetings_training:
                feature_questions_greetings.append(x['questions'])
                feature_lables_greetings.append(int(x['qid']))

            for x in Greetings_answers:
                del x["_id"]
                all_ans_greetings.append(x)

            for x in Faq_training:
                faq_bot_questions.append(x['questions'])
                faq_bot_lables.append(int(x['qid']))

            for _ in faq_answers:
                del _["_id"]
                faq_answers_data.append(_)
            return feature_questions_greetings,feature_lables_greetings,all_ans_greetings,faq_bot_questions,faq_bot_lables,\
                   faq_answers_data,intent_classifier_questions,intent_classifier_labels
        except Exception as e:
            raise str(e)


obj1=Mongo_data()
obj1.all_collections()

