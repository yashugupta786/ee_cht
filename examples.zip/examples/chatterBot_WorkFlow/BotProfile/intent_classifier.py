__author__ = "Yashu Gupta"
# ---------------------------------------ALL IMPORTS------------------------------------------------------------------------------------------->>
import random, nltk, string
import os.path as path
bot_profile_config = path.abspath(path.join(__file__, "../.."))
config_file_loc = bot_profile_config + "/config/Config.cfg"
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from chatterBot_WorkFlow.src.dictionary_bot import dict_classifier
from chatterBot_WorkFlow.src import UserMessages
from chatterBot_WorkFlow.src.stop_words import stopper
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from Mongo_connections import Mongo_data
lemma = nltk.WordNetLemmatizer()
import re, sys
import configparser

reload(sys)
sys.setdefaultencoding('utf8')
sys.path.insert(0, "../../")
# from chatterBot_WorkFlow.src.chatbotSeekersApplyJobs import logger

# ----------------------Defining thresholds------------------------------------------
upperThresh = 0.58
lowerThresh = 0.28

# -------------------------------------Conigs import---------------------------------------------
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    debugLevel = int(config_obj.get("Logs", "debuglevel"))
    logfilenameconfig = config_obj.get("Logs", "logfilename")
    MaxTry = int(config_obj.get("BotConfig", "MaxTry"))
    BotConfiScore = float(config_obj.get("BotConfig", "BotConfiScore"))
    MaxCon = int(config_obj.get("BotConfig", "MaxCon"))
    BotConverCount = int(config_obj.get("BotConfig", "BotConverCount"))
    MaxFaqs = int(config_obj.get("BotConfig", "MaxFaqs"))

except Exception as e:
    raise Exception("Config file error: " + str(e))


# <<------------------- fetching the one time data from the database for the model training---------------------------------------------------->>
TEXT_CLASSIFIER = None
class BotType(object,Mongo_data):
    """
    Bot type class - model training for intent classfication
    classifier used SGD with svm quatratic (modified huber loss)
    :return class returns the type of the bot with the score
    """

    def __init__(self,mongo_obj):
        self.Allmsgs = UserMessages.IntializeMessages()
        self.mongo_list = mongo_obj.all_collections()
        self.feature_questions_intent= self.mongo_list[6]
        self.labels_intent = self.mongo_list[7]

    def ml_chatbot(self):
        """
               Training the machine learning model for one time classfication for greetings
               parameters required SGD engine , with SVM
               libray used for training the model SK-LEarn

               :return: Text classifier(vector)
               """
        try:
            global TEXT_CLASSIFIER
            feature_questions_output = []
            feature_questions = self.feature_questions_intent
            feature_lables = self.labels_intent
            _feature_questions = []
            _feature_questions_noun = []
            _feature_questions_verb = []
            feature_questions_punct = [''.join(c for c in s if c not in string.punctuation) for s in feature_questions]
            feature_questions_spc = [s for s in feature_questions_punct if s]
            for i in feature_questions_spc:
                _feature_questions.append(re.sub('\s+', ' ', i).strip())
            feature_questions_lwr = [x.lower() for x in _feature_questions]
            feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                                      feature_questions_lwr]
            for i in feature_questions_noun:
                _feature_questions_noun.append(" ".join(i))
            feature_questionsverb = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                                     _feature_questions_noun]
            for i in feature_questionsverb:
                _feature_questions_verb.append(" ".join(i))
            for s in _feature_questions_verb:
                for word in dict_classifier.keys():
                    if word in s:
                        s = re.sub(r'\b' + word + '\\b', dict_classifier[word], s)
                feature_questions_output.append(s)
            stoppy_words = [(x.strip()) for x in stopper]
            tfidf_vectorizer = TfidfVectorizer(ngram_range=(1, 3))
            text_classifier = Pipeline([
                ('vectorizer', tfidf_vectorizer),
                ('clf', MultinomialNB(alpha=1.0))
            ])
            TEXT_CLASSIFIER = text_classifier.fit(feature_questions_output, feature_lables)
            global flag
            flag = True
        except Exception as exception:
            print (str(exception))

    #
    def fetch_interpreted(self, question, dict_classifier):
        """
        :param question:
        :param dict_classifier:
        :return: questions, probablity score, vector
        """
        global TEXT_CLASSIFIER
        if TEXT_CLASSIFIER is None:
            self.ml_chatbot()
            print("fit again intent classifier")
        query = [question]
        query_label = []
        _feature_questions_noun_user = []
        _feature_questions_verb_user = []
        quer_label_space = []
        feature_questions_noun = [[lemma.lemmatize(word, 'n') for word in sentence.split(" ")] for sentence in
                                  query]
        for i in feature_questions_noun:
            _feature_questions_noun_user.append(" ".join(i))
        feature_questions_verb1 = [[lemma.lemmatize(word, 'v') for word in sentence.split(" ")] for sentence in
                                   _feature_questions_noun_user]
        for i in feature_questions_verb1:
            _feature_questions_verb_user.append(" ".join(i))
        for s in _feature_questions_verb_user:
            for word in dict_classifier.keys():
                if word in s:
                    s = re.sub(r'\b' + word + '\\b', dict_classifier[word], s)
            query_label.append(s)
        pred = TEXT_CLASSIFIER.predict(query_label)
        otherpreds1 = TEXT_CLASSIFIER.predict_proba(query_label)

        inter_q = pred
        return inter_q, otherpreds1, _feature_questions_verb_user

    def getAnswer_intent(self, que):
        """
        :param que:
        :return: top score ,Bottype
        """
        question = que
        botType = 'greetings'
        top_score = 0.0
        try:
            inter_q, scores_received, _feature_questions_verb_user = self.fetch_interpreted(question, dict_classifier)
            returned_label = int(inter_q[0])
            top_score = scores_received[0]
            greetingScore = top_score[0]
            faqScore = top_score[1]
            query_received = _feature_questions_verb_user[0]
            if (faqScore > lowerThresh and faqScore < upperThresh) and returned_label == 0:
                query_tokens = query_received.lower().split()
                for x in query_tokens:
                    if x in self.Allmsgs.faqsListType:
                        returned_label = 1
                        break
            if returned_label == 0:
                botType = 'greetings'
            else:
                botType = 'faqs'
        except Exception as e:
            print (str(e))
        return top_score, botType


if __name__ == "__main__":
    question = ""
    gtObj = BotType()
    while question != "exit()":
        que = raw_input("Enter Sentence: ")
        score, botType = gtObj.getAnswer_intent(que)
        print (score, botType)
