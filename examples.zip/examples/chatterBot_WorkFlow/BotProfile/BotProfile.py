# This class has functions related model training and storage  and etching interpreted questions
__author__ = "Yashu Gupta"
# ---------------------------------------ALL IMPORTS------------------------------------------------------------------------------------------->>
import random
import os.path as path
bot_profile_config = path.abspath(path.join(__file__, "../.."))
config_file_loc = bot_profile_config + "/config/Config.cfg"
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import nltk, string
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn import preprocessing
lemma = nltk.WordNetLemmatizer()
import re, sys
import configparser, os
reload(sys)
sys.setdefaultencoding('utf8')
sys.path.insert(0, "../../")
from chatterBot_WorkFlow.src.dictionary_bot import dict_classifier
import Mongo_connections
from Mongo_connections import Mongo_data
# from chatterBot_WorkFlow.src.chatbotSeekersApplyJobs import logger
# -------------------------------------------------------------------------------------------------------------------------------------
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    debugLevel = int(config_obj.get("Logs", "debuglevel"))
    logfilenameconfig = config_obj.get("Logs", "logfilename")
    MaxTry = int(config_obj.get("BotConfig", "MaxTry"))
    BotConfiScore = float(config_obj.get("BotConfig", "BotConfiScore"))
    MaxCon = int(config_obj.get("BotConfig", "MaxCon"))
    BotConverCount = int(config_obj.get("BotConfig", "BotConverCount"))
    MaxFaqs = int(config_obj.get("BotConfig", "MaxFaqs"))

except Exception as e:
    raise Exception("Config file error: " + str(e))
# <<------------------- fetching the one time data from the database for the model training---------------------------------------------------->>
TEXT_CLASSIFIER = None
class BotProfileChatBot(Mongo_data):
    """
         FAQ_query class - model training for intent classfication
         classifier used SGD with svm quatratic (modified huber loss),TFidf vectorizer 
         :return class returns the answer with the score
    """

    def __init__(self, mongo_obj):
        self.mongo_list = mongo_obj.all_collections()
        self.feature_questions_greetings = self.mongo_list[0]
        self.feature_lables_greetings = self.mongo_list[1]
        self.all_ans_greetings = self.mongo_list[2]



    def ml_chatbot(self):
        """
        Training the machine learning model for one time classfication for greetings
        parameters required SGD engine , with SVM
        libray used for training the model SK-LEarn
        :return: Text classifier(vector)
        """
        try:
            global TEXT_CLASSIFIER
            feature_questions = self.feature_questions_greetings
            feature_lables =self.feature_lables_greetings
            _feature_questions = []
            cleaned_data = []
            feature_questions_output = []
            feature_questions = [''.join(c for c in s if c not in string.punctuation) for s in feature_questions]
            feature_questions = [s for s in feature_questions if s]
            for i in feature_questions:
                _feature_questions.append(re.sub('\s+', ' ', i).strip())
            feature_questions_lwr = [x.lower() for x in _feature_questions]
            for s in feature_questions_lwr:
                for word in dict_classifier.keys():
                    if word in s:
                        s = re.sub(r'\b' + word + '\\b', dict_classifier[word], s)
                cleaned_data.append(s)
            feature_questions1 = [[lemma.lemmatize(word) for word in sentence.split(" ")] for sentence in cleaned_data]
            for i in feature_questions1:
                feature_questions_output.append(" ".join(i))
            self.label_encoder_data = preprocessing.LabelEncoder()
            self.label_encoder_data.fit(feature_lables)
            interpretation_all_data = self.label_encoder_data.transform(feature_lables)
            count_vectorizer = TfidfVectorizer(ngram_range=(1, 3))
            text_classifier = Pipeline([
                ('vectorizer', count_vectorizer),
                ('clf', SGDClassifier(loss='modified_huber',
                                      alpha=1e-3,
                                      n_jobs=-1,
                                      max_iter=15,
                                      random_state=0,
                                      shuffle=True))
            ])
            TEXT_CLASSIFIER = text_classifier.fit(feature_questions_output, interpretation_all_data)
            global flag
            flag = True
        except Exception as exception:
            print (str(exception))

    def fetch_interpreted(self, question, dict_classifier):
        """
               :param question:
               :param dict_classifier:
               :return: questions, probablity score, vector
        """
        global TEXT_CLASSIFIER
        if TEXT_CLASSIFIER is None:
            self.ml_chatbot()
            print("fit again")
        query = [question]
        query_label = []
        strip_sent = []
        cleaned_data_dict = []
        for s in query:
            for word in dict_classifier.keys():
                if word in s:
                    s = re.sub(r'\b' + word + '\\b', dict_classifier[word], s)
            cleaned_data_dict.append(s)
        results2 = [[lemma.lemmatize(word) for word in sentence.split(" ")] for sentence in cleaned_data_dict]
        for i in results2:
            query_label.append(" ".join(i))
        otherq = []
        scores = []
        pred = TEXT_CLASSIFIER.predict(query_label)
        otherpreds = TEXT_CLASSIFIER.predict_proba(query_label)[0]
        i = 0
        limit = 3
        if (len(otherpreds) < 3):
            limit = len(otherpreds)
        while i < limit:
            max_score = np.argmax(otherpreds)
            otherq.append(max_score)
            scores.append(otherpreds[max_score])
            otherpreds[max_score] = -1
            i += 1
        inter_q = self.label_encoder_data.inverse_transform(pred)
        return inter_q, scores

    def return_answer(self, returned_label,all_ans_greetings):
        """
               :param returned_label: 
               :return:answer 
        """
        try:
            returned_answers = []
            return_question = []
            for j in all_ans_greetings:
                if j["qid"] == int(returned_label):
                    returned_answers.append(j["answers"])
            random_returnd_ans = (random.choice(returned_answers))
            return random_returnd_ans
        except Exception as exception:
            print ("data error",str(exception))
            return ''

    def getAnswer(self, que):
        """
               :param returned_label: 
               :return:answer 
        """
        question = que
        inter_q, scores_received = (self.fetch_interpreted(question, dict_classifier))
        # print 'returned label -------->',inter_q[0]
        returned_label = str(inter_q[0])
        top_score = scores_received[0]
        return top_score, self.return_answer(returned_label,self.all_ans_greetings)


#
if __name__ == "__main__":
    question = ""
    mongo_object=Mongo_connections.Mongo_data()
    gtObj = BotProfileChatBot()
    while question != "exit()":
        que = raw_input("Enter Sentence: ")
        score, ans = gtObj.getAnswer(que)
        print (score, ans)
