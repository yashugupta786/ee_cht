
from pymongo import MongoClient
import configparser
import urllib2
import urllib
import pymongo,sys,os

import os.path as path
# -------------------(new change apache)getting new configs----------------
django_path =  path.abspath(path.join(__file__ ,"../../.."))
print(django_path)
sys.path.append(os.path.join(django_path, ''))
new_config_path = path.abspath(path.join(__file__, "../../.."))
config_file_loc = new_config_path + "/chatterBot_WorkFlow/config/Config.cfg"
config_obj = configparser.ConfigParser()


# ------------------------------------------fetching one time data from configs----------------------------------------------

try:
    config_obj.read(config_file_loc)
    debugLevel = int(config_obj.get("Logs", "debuglevel"))
    logfilenameconfig = config_obj.get("Logs", "logfilename")
    MongoIP = (config_obj.get("mongoDetails", "MongoIP"))
    MongoPort = int(config_obj.get("mongoDetails", "MongoPort"))
    db_name = (config_obj.get("mongoDetails", "db_name"))
    mongo_username = (config_obj.get("mongoDetails", "mongo_username"))
    mongo_pwd = (config_obj.get("mongoDetails", "mongo_pwd"))

except Exception as e:
    raise Exception("Config file error: " + str(e))


mongo_uri = "mongodb://" + mongo_username + ":" + urllib.quote(mongo_pwd) + "@" + MongoIP + "/" + db_name
client = pymongo.MongoClient(mongo_uri)
#db = client.bazooka
print client.server_info()
print client.runCommand( { "connectionStatus": 1," showPrivileges": True } )
# print client.close()
# data =  client.runCommand( { "serverStatus": 1, "repl": 0, "metrics": 0, "locks": 0 } )
# print data
