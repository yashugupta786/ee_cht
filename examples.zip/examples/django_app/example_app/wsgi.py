import os,sys
from django.core.wsgi import get_wsgi_application
# path = '/home/yashu/Desktop/Monster_chatterBot/examples/django_app/'
#----------------------getting all paths from root -------------------------
path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(path, ''))
l=os.environ.setdefault("DJANGO_SETTINGS_MODULE", "example_app.settings")
application = get_wsgi_application()
