from django.conf.urls import include, url
from django.contrib import admin
from example_app.views import ChatterBotAppView, get_data, get_VoiceApplyIntent, get_FirstVoiceClick


urlpatterns = [
    url(r'^$', ChatterBotAppView, name='main'),
    url(r'^admin/', include(admin.site.urls), name='admin'),
    url(r'^get_data/$', get_data, name='get_data'),
    url(r'^get_VoiceApplyIntent/$', get_VoiceApplyIntent, name='get_VoiceApplyIntent'),
    url(r'^get_FirstVoiceClick/$', get_FirstVoiceClick, name='get_FirstVoiceClick')

]


