domain_url="https://my.monstergulf.com/login.html"
# domain_url="https://my.monsterindia.com/my_monster.html?randck=655781539064128"
# domain_url="https://my.monstergulf.com/my_monster.html?randck=655781539064128"
# domain_url="https://my.monsterindia.com/my_monster.html?randck=655781539064128"

Ans="To know more about Xpress Resume+, please visit http://expressresume.monsterindia.com/ using xpress resume one can improve the existing resume"

import re
IsUrl = re.findall(r'https?://\w+\.(\w+\.\w+(\.\w+)?)/', Ans)
listDomainToRemove = ["my.","www."]
domain_text = domain=domain_url.split("//")[-1].split("/")[0]

for d in listDomainToRemove:
    if domain_text.startswith(d):
        domain_text = domain_text[len(d):]
        break

print domain_text
if len(IsUrl)>0:
    for url in IsUrl:
        Ans = Ans.replace(url[0], domain_text)
    # data = domain_url.split("/")
    # searchUrl = data[0] + "//" + data[2]
    # Ans= Ans.replace(IsUrl[0][0], searchUrl)
print Ans.replace("http:","https:")