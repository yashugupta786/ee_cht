$(document).ready(function(){
        $(".left-first-section").click(function(){
            $('.main-section').toggleClass("open-more");
        });
    });
    $(document).ready(function(){
        $(".fa-minus").click(function(){
            $('.main-section').toggleClass("open-more");
        });
    });


$(document).ready(function(){
 var chatterbotUrl = '{% url "get_data" %}';
      var csrftoken = Cookies.get('csrftoken');

      function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
      }

      $.ajaxSetup({
        beforeSend: function(xhr, settings) {
          if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
          }
        }
      });

      var $chatlog = $('.js-chat-log');
      var $input = $('.js-text');
      console.log($input)
      var $sayButton = $('.js-say');
      function createRow(text) {
        var $row = "<li><div class='left-chat'><img src='{% static 'img/img_avatar.png' %}'><p>"+text+"</p></div></li>"

        <!--$row.text(text);-->
        $chatlog.append($row);
      }
      function createRowUser(text) {
        var $row = "<li><div class='left-chat'><img src='{% static 'img/img_avatar.png' %}'><p>"+text+"</p></div></li>"

        <!--$row.text(text);-->
        $chatlog.append($row);
      }

      function submitInput() {
      var card_type = ""
      if($("input[type='radio'].radioBtnClass").is(':checked')) {
        var card_type = $("input[type='radio'].radioBtnClass:checked").val();

        }
        <!--alert(card_type);-->
        var inputData = {
          'text': $input.val(),
          'select_value':card_type

        }
        console.log('-----------'+$input.val())
        // Display the user's input on the web page
        createRowUser(inputData.text);

        var $submit = $.ajax({
          type: 'POST',
          url: chatterbotUrl,
          data: JSON.stringify(inputData),
          contentType: 'application/json'
        });

        $submit.done(function(statement) {
            for (i = 0; i < statement.text.length; i++) {
            createRow(statement.text[i]);
            }
            // Clear the input field
            $input.val('');

            // Scroll to the bottom of the chat interface
            $chatlog[0].scrollTop = $chatlog[0].scrollHeight;
        });

        $submit.fail(function() {
          // TODO: Handle errors
        });
      }

      $sayButton.click(function() {
      <!--alert("hi")-->
        submitInput();
      });

      $input.keydown(function(event) {
        // Submit the input when the enter button is pressed
        if (event.keyCode == 13) {
          submitInput();
        }
      });
});
