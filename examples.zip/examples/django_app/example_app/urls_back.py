from django.conf.urls import include, url
from django.contrib import admin
from example_app.views import ChatterBotAppView, get_data


urlpatterns = [
    url(r'^$', ChatterBotAppView, name='main'),
    url(r'^admin/', include(admin.site.urls), name='admin'),
    url(r'^get_data/$', get_data, name='get_data')

]


