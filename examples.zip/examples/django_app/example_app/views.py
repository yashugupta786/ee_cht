import sys, os
sys.path.insert(0,"../")
import os.path as path
django_path =  path.abspath(path.join(__file__ ,"../../.."))
sys.path.append(os.path.join(django_path, ''))
from django.views.decorators.clickjacking import xframe_options_exempt
import json
from django.shortcuts import render
from django.http import JsonResponse
import datetime, time
import configparser
import requests
from chatterBot_WorkFlow.src.loggingmodule import get_logger_feedback
from chatterBot_WorkFlow.src.chatbotSeekersApplyJobs import Chatbot
#-------------------(new change apache)getting new configs----------------

new_config_path =  path.abspath(path.join(__file__ ,"../../.."))
config_file_loc = new_config_path + "/chatterBot_WorkFlow/config/Config.cfg"
config_obj = configparser.ConfigParser()
data={}
#------------------------------------------fetching one time data from configs----------------------------------------------

try:
    config_obj.read(config_file_loc)
    debugLevel = int(config_obj.get("Logs", "debuglevel"))
    logfilenameconfig = config_obj.get("Logs", "logfilename")
    chatbotSession_url = str(config_obj.get("chatbotSession", "chatbot_session"))


except Exception as e:
    raise Exception("Config file error: " + str(e))
LOG_DIR =  path.abspath(path.join(__file__ ,"../../.."))

logfilename = LOG_DIR + "/logs/chatbotlogs.log"
nowtime = datetime.datetime.now()
loggerobj1 = get_logger_feedback.GetLogger_feedback(name="chatbot1", logfileloc=logfilename, debuglevel=debugLevel)
logger = loggerobj1.getlogger2()
#-----------------------------------------------------------------------------------------------------------------------------------------------

def UserSessionsDetails(zCookie):
    try:
        userSession = requests.post(url=chatbotSession_url, data={"z-cookie": zCookie}).json()
        logger.info(str(userSession))
        loginKeys = ["SID", "NAME", "UID", "CURRENTLOCATION", "FNAME", "LOGIN", "LNAME"]
        for x in loginKeys:
            if x not in userSession or userSession[x]==None:
                userSession[x] = ''
    except Exception as e:
        userSession = {"SID": "ExceptionInGeneratingUserSession", "NAME": None, "UID": 0,
                   "CURRENTLOCATION": "Bhopal", "FNAME": '', "LOGIN": 0, "LNAME": None}

    return userSession

timestamp=str(nowtime.year)+str(nowtime.month)+str(nowtime.day)
converId=int(timestamp)+0
#---------------------------------------------------global object calling------------------------------------
def init():
    global cb
    cb = Chatbot()

init()
#-------------------------------------------------------------------------------------------------------------------------------
@xframe_options_exempt
def ChatterBotAppView(request):
    mainList = []
    getwelcomeMsgsList = cb.intializeMessages()
    welcomeMsg = getwelcomeMsgsList
    return render(request, "app.html", {"data": welcomeMsg})


#---------------------------------------------------calling get_data function from urls in the UI End ------------------------------
@xframe_options_exempt
def get_data(request):
    global converId
    try:
        if request.method == "POST":
            converId=converId+1
            #print '='*50
            input_data = json.loads(request.read().decode('utf-8'))
            if input_data["zcookie"]!="" or input_data["zcookie"]!=None or input_data["zcookie"]:
                uSessionCookie = input_data["zcookie"]
                userSession = UserSessionsDetails(zCookie=uSessionCookie)
            else:
                userSession = {"SID": "NoUSerSessionFound", "NAME": None, "UID": 0,
                   "CURRENTLOCATION": "Bhopal", "FNAME": '', "LOGIN": 0, "LNAME": None}

            uQuery = input_data["text"]
            uLocation = ''
            uSession=userSession['SID']
            uid=userSession['UID']
            uname=userSession['NAME']
            uFname = userSession['FNAME']
            domain_url=input_data["domain_url"]
            print(domain_url)
            responseList,JobDetails,searchUrl,AnswerType,skillsFound = cb.extractInfo(uQuery,uLocation,uFname,domain_url)
            # responseList, JobDetails, searchUrl, AnswerType= cb.extractInfo(uQuery, uLocation)
            data = {
                          'text':responseList,
                           'JobDetails':JobDetails,
                            'SearchUrl':searchUrl

                        }
            mongodata = {'queryTime':str(nowtime),'uid':uid,'userSession':uSession,'uName':uname,'converId ':converId,'statement': uQuery, 'response': responseList,'AnswerType':AnswerType,'skills found':skillsFound,'Fname':uFname}
            logger.info(mongodata)

    except Exception as e:
        logger.error('Exception occured at getting (getdata) : ' + str(e))

        responseList=[]
    return JsonResponse(data, status=200,)



#---------------------------------------------------calling get_data function from urls in the UI End ------------------------------
@xframe_options_exempt
def get_VoiceApplyIntent(request):
    global converId
    try:
        if request.method == "POST":
            converId=converId+1
            #print '='*50
            input_data = json.loads(request.read().decode('utf-8'))
            uQuery = input_data["text"]


            applyIntentType= cb.applyIntent(que=uQuery)
            # responseList, JobDetails, searchUrl, AnswerType= cb.extractInfo(uQuery, uLocation)
            data = {
                          'applyIntentType':applyIntentType,


                        }
            #mongodata = {'queryTime':str(nowtime),'uid':uid,'userSession':uSession,'uName':uname,'converId ':converId,'statement': uQuery, 'response': responseList,'AnswerType':AnswerType,'skills found':skillsFound,'Fname':uFname}
            #logger.info(mongodata)

    except Exception as e:
        logger.error('Exception occured at getting (get_VoiceApplyIntent) : ' + str(e))

        responseList=[]
    return JsonResponse(data, status=200,)


@xframe_options_exempt
def get_FirstVoiceClick(request):
    global converId
    try:
        if request.method=="POST":
            converId=converId+1
        input_data = json.loads(request.read().decode('utf-8'))
        if input_data["zcookie"] != "" or input_data["zcookie"] != None or input_data["zcookie"]:
            uSessionCookie = input_data["zcookie"]
            userSession = UserSessionsDetails(zCookie=uSessionCookie)
        else:
            userSession = {"SID": "NoUSerSessionFound", "NAME": None, "UID": 0,
                           "CURRENTLOCATION": "Bhopal", "FNAME": '', "LOGIN": 0, "LNAME": None}
        uQuery = input_data["text"]
        uLocation = ''
        uSession = userSession['SID']
        uid = userSession['UID']
        uname = userSession['NAME']
        uFname = userSession['FNAME']
        first_voice_query=cb.first_voicequery(uQuery,uFname)
        data = {
            'first_voice_que': first_voice_query,

        }
    except Exception as e:
        logger.error('Exception occured at getting (get_firstQueryIntent) : ' + str(e))

    return JsonResponse(data, status=200, )
